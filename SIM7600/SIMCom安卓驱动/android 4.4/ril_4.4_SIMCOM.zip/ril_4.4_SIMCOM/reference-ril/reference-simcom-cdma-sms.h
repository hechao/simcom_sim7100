/*============================================================================
   DESCRIPTION
       This file implements the CDMA RIL message encode/decode.

 Copyright (c) 2013 SIMCom, Incorporated.  All Rights Reserved.
============================================================================*/

/*============================================================================

                      EDIT HISTORY FOR FILE

 This section contains comments describing changes made to this file.
 Notice that changes are listed in reverse chronological order.

 Header: hardware/ril/reference-ril/reference-ril-simcom.h

 when            who            what, where, why     
 --------     ----  ----------------------------------------------------------
 
14/01/10     wjl        initial version
============================================================================*/

#ifndef REFERENCE_SIMCOM_CDMA_SMS_H
#define REFERENCE_SIMCOM_CDMA_SMS_H 1

#ifdef SIMCOM_RADIO_CDMA            

#include <telephony/ril.h>
#include <telephony/ril_cdma_sms.h>

/*===========================================================================

FUNCTION simcom_cdma_decode_sms

DESCRIPTION
    Decode a CDMA SMS Message
  
PARAMETERS
    [in] encoded_sms -  the sms to encode
    [out] msg  -    the sms PDU

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
RIL_Errno simcom_cdma_decode_sms (
    RIL_CDMA_Encoded_SMS * encoded_sms,   /* Input */
    RIL_CDMA_SMS_Message * msg      /* Output */
);

/*===========================================================================

FUNCTION simcom_cdma_encode_sms

DESCRIPTION
    Encode a CDMA SMS Message
  
PARAMETERS
    [in] msg  -    the sms PDU
    [out] encoded_sms -  the sms to encode

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
RIL_Errno simcom_cdma_encode_sms (
    RIL_CDMA_SMS_Message * msg,     /* Input */
    RIL_CDMA_Encoded_SMS * encoded_sms    /* Output */
);

#endif /* SIMCOM_RADIO_CDMA */

#endif /*REFERENCE_SIMCOM_CDMA_SMS_H*/

