/*============================================================================
   DESCRIPTION
       This file implements the CDMA RIL message encode/decode.

 Copyright (c) 2013 SIMCom, Incorporated.  All Rights Reserved.
============================================================================*/

/*============================================================================

                      EDIT HISTORY FOR FILE

 This section contains comments describing changes made to this file.
 Notice that changes are listed in reverse chronological order.

 Header: hardware/ril/reference-ril/reference-ril-simcom.h

 when            who            what, where, why     
 --------     ----  ----------------------------------------------------------
 
14/01/10     wjl        initial version
============================================================================*/
     
#include "reference-ril-simcom.h"
#include "reference-simcom-cdma-sms.h"

#ifdef SIMCOM_RADIO_CDMA            

#undef LOG_TAG
#define LOG_TAG "CDMA"
#include <utils/Log.h>


#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define MAX(a,b) ((a) > (b) ? a : b)

/*===========================================================================
MACRO bitsize

DESCRIPTION
   Computes size in bits of the specified data type.
===========================================================================*/
#define bitsize(type) (sizeof(type) * 8)

/*===========================================================================
MACRO copymask

DESCRIPTION
   Creates a mask of bits sized to the number of bits in the given type.
===========================================================================*/
#define copymask(type) ((0xffffffff) >> (32 - bitsize(type)))

/*===========================================================================
MACRO MASK

DESCRIPTION
   Masks the bits in data at the given offset for given number of width bits.
===========================================================================*/
#define MASK(width, offset, data) \
    /*lint -e701 shift left  of signed quantity  */  \
    /*lint -e702 shift right of signed quantity  */  \
    /*lint -e572 Excessive shift value           */  \
    /*lint -e573 Signed-unsigned mix with divide */  \
    /*lint -e506 Constant value boolean          */  \
    /*lint -e649 Sign fill during constant shift */  \
                                                     \
   (((width) == bitsize(data)) ? (data) :   \
   ((((copymask(data) << (bitsize(data) - ((width) % bitsize(data)))) & copymask(data)) >>  (offset)) & (data))) \
                     \
    /*lint +e701 */  \
    /*lint +e702 */  \
    /*lint +e572 */  \
    /*lint +e573 */  \
    /*lint +e506 */  \
    /*lint +e649 */  

/*===========================================================================
MACRO MASK_AND_SHIFT

DESCRIPTION
   Same as the macro MASK except also shifts the data in the result by the
   given number of shift bits.
===========================================================================*/
#define MASK_AND_SHIFT(width, offset, shift, data)  \
    /*lint -e504 Unusual shifter value */  \
                  ((((signed) (shift)) < 0) ?       \
                    MASK((width), (offset), (data)) << -(shift) :  \
                    MASK((width), (offset), (data)) >>  (((unsigned) (shift)))) \
    /*lint +e504 */

/*===========================================================================
MACRO MASK_AND_SHIFT_RIGHT

DESCRIPTION
   Same as the macro MASK except also shifts the data in the result right
   by the given number of shift bits.
===========================================================================*/
#define MASK_AND_SHIFT_RIGHT(width, offset, shift, data)   \
                    (MASK((width), (offset), (data)) >>  ((unsigned)(shift)))

/*===========================================================================
MACRO MASK_AND_SHIFT_LEFT

DESCRIPTION
   Same as the macro MASK except also shifts the data in the result left
   by the given number of shift bits.
===========================================================================*/
#define MASK_AND_SHIFT_LEFT(width, offset, shift, data)    \
                    (MASK((width), (offset), (data)) << ((unsigned)(shift)))

/*===========================================================================
MACRO MASK_B

DESCRIPTION
   Masks the number of bits give by length starting at the given offset.
   Unlike MASK and MASK_AND_SHIFT, this macro only creates that mask, it
   does not operate on the data buffer.
===========================================================================*/
#define MASK_B(offset, len) \
  ((0xff >> offset) & (0xff << (8 - (offset + len))))

/*===========================================================================
MACRO LITLEND_PTR_ADD

DESCRIPTION
   This macro adds offsets to byte pointers operating on little_endian word
   buffers. The pointer p to a word buffer should initially have been
   exclusive_ORed with 1. Further add operations on such a pointer using
   this macro will lead to the correct offset in a little endian word buffer.
===========================================================================*/
#define LITLEND_PTR_ADD(p,i)     (((((unsigned long)(p))^1)+(i))^1)

#define TL_HEADER_SIZE    1
#define TL_PARM_SIZE      2

/* Transport Layer message types
*/
typedef enum
{
    WMS_TL_TYPE_MIN               = 0,
    WMS_TL_TYPE_POINT_TO_POINT    = 0,
    WMS_TL_TYPE_BROADCAST         = 1,
    WMS_TL_TYPE_ACK               = 2,
    WMS_TL_TYPE_MAX               = 2
}wms_tl_message_type_e_type;

/* Status:
*/
typedef enum
{
    WMS_OK_S                  = 0,
    WMS_OUT_OF_RESOURCES_S,   /* e.g. out of memory buffer */
    WMS_TERMINAL_BLOCKED_S,
    WMS_TERMINAL_BUSY_S,
    WMS_INVALID_TRANSACTION_ID_S,
    WMS_INVALID_FORMAT_S,
    WMS_GENERAL_ERROR_S,
    WMS_UNSUPPORTED_S,
    WMS_NULL_PTR_S,
  
    /* CDMA only
    */
    WMS_INVALID_PARM_SIZE_S   = 100,
    WMS_INVALID_USER_DATA_SIZE_S,
    WMS_INVALID_PARM_VALUE_S,
    WMS_MISSING_PARM_S,
    WMS_NETWORK_NOT_READY_S,
    WMS_PHONE_NOT_READY_S,
    WMS_NOT_ALLOWED_IN_AMPS_S,
    WMS_NETWORK_FAILURE_S,
    WMS_ACCESS_TOO_LARGE_S,
    WMS_DTC_TOO_LARGE_S,
    WMS_ACCESS_BLOCK_S,
    WMS_ESN_MISMATCH_S, /* for JCDMA2 feature only */
  
    /* GSM/WCDMA only
    */
    WMS_INVALID_TPDU_TYPE_S  = 200,
    WMS_INVALID_VALIDITY_FORMAT_S,
    WMS_INVALID_CB_DATA_S,
    WMS_MT_MSG_FAILED_S, /* internal use */
  
    /* SIP errors
    */
    WMS_SIP_PERM_ERROR_S     = 300,
    WMS_SIP_TEMP_ERROR_S,
  
    /* WMSC, CS and RPC errors
    */
    WMS_WMSC_ERROR_S         = 400,
    WMS_CS_ERROR_S,
    WMS_RPC_ERROR_S,
  
    WMS_STATUS_MAX,
    WMS_STATUS_MAX32 = 0x10000000    /* pad to 32 bit int */
} wms_status_e_type;

#define WMS_GW_TEMPLATE_MIN         28

enum { WMS_SMS_UDL_MAX_7_BIT  = 160 }; /* as in the spec */
enum { WMS_SMS_UDL_MAX_8_BIT  = 140 }; /* as in the spec */

enum { WMS_GW_CB_PAGE_HEADER_LEN = 6 };
enum { WMS_GW_CB_MAX_PAGE_USER_DATA_LEN = 93 };
enum { WMS_GW_CB_PAGE_SIZE    = 88 };

enum { WMS_TL_MAX_LEN        = 246 };

#define WMS_RUIM_SMSP_EMPTY_CHAR    0xFF
#define WMS_RUIM_SMSP_EMPTY_CHAR2   0x00

enum{ WMS_DUMMY_SEQ_NUM         = 0x80 };

enum { WMS_SIM_SMS_MAX  = 176 }; /* as in the spec */

/* Transport Layer parameter mask values:
*/
enum{ WMS_MASK_TL_NULL                = 0x00000000 };
enum{ WMS_MASK_TL_TELESERVICE_ID      = 0x00000001 };
enum{ WMS_MASK_TL_BC_SRV_CATEGORY     = 0x00000002 };
enum{ WMS_MASK_TL_ADDRESS             = 0x00000004 };
enum{ WMS_MASK_TL_SUBADDRESS          = 0x00000008 };
enum{ WMS_MASK_TL_BEARER_REPLY_OPTION = 0x00000040 };
enum{ WMS_MASK_TL_CAUSE_CODES         = 0x00000080 };
enum{ WMS_MASK_TL_BEARER_DATA         = 0x00000100 };

/* Transport Layer parameter Ids:
*/
typedef enum
{
    WMS_TL_DUMMY          = -1,  /* dummy */
    WMS_TL_TELESERVICE_ID = 0,  /* Teleservice Identifier     */
    WMS_TL_BC_SRV_CATEGORY,     /* Broadcast Service Category */
    WMS_TL_ORIG_ADDRESS,        /* Originating Address        */
    WMS_TL_ORIG_SUBADDRESS,     /* Originating Subaddress     */
    WMS_TL_DEST_ADDRESS,        /* Destination Address        */
    WMS_TL_DEST_SUBADDRESS,     /* Destination Subaddress     */
    WMS_TL_BEARER_REPLY_OPTION, /* Bearer Reply Option        */
    WMS_TL_CAUSE_CODES,         /* Cause Codes                */
    WMS_TL_BEARER_DATA          /* Bearer Data                */
} wms_tl_parm_id_e_type;


/* ------------------------ */
/* ---- Teleservice Id ---- */
/* ------------------------ */
typedef enum
{
    /*----------------------------------------------------------------
       The following values 0 - 0xFFFF are used in CDMA mode and Analog
       AWI SMS as defined in IS-637/IS-41.
    -----------------------------------------------------------------*/
  
    /* NOTE: In case of teleservice CM_91, the encoding type of the user data
       indicates whether the teleservice is actually CPT, VMN or CMT and the
       user data is extracted into the corresponding bearer data fields.
    */
    WMS_TELESERVICE_CMT_91             = 4096,  /* embedded IS91 SMS */
    WMS_TELESERVICE_CPT_95             = 4097,  /* page */
    WMS_TELESERVICE_CMT_95             = 4098,  /* short message */
    WMS_TELESERVICE_VMN_95             = 4099,  /* voice mail notification */
    WMS_TELESERVICE_WAP                = 4100,  /* WAP */
    WMS_TELESERVICE_WEMT               = 4101,  /* Enhanced Messaging/EMS */
    WMS_TELESERVICE_SCPT               = 4102,  /* Srv Category Programming */
    WMS_TELESERVICE_CATPT              = 4103,  /* Card App Toolkit Protocol */
  
    WMS_TELESERVICE_GSM1x_01           = 4104,  /* GSM1x signalling message */
    WMS_TELESERVICE_GSM1x_02           = 4105,  /* GSM1x short message */
    WMS_TELESERVICE_GSM1x_03           = 4106,  /* Reserved for now */
    WMS_TELESERVICE_GSM1x_04           = 4107,  /* Reserved for now */
    WMS_TELESERVICE_GSM1x_05           = 4108,  /* Reserved for now */
    WMS_TELESERVICE_GSM1x_06           = 4109,  /* Reserved for now */
    WMS_TELESERVICE_GSM1x_07           = 4110,  /* Reserved for now */
    WMS_TELESERVICE_GSM1x_08           = 4111,  /* Reserved for now */
    WMS_TELESERVICE_GSM1x_09           = 4112,  /* Reserved for now */
    WMS_TELESERVICE_GSM1x_10           = 4113,  /* Reserved for now */
  
    WMS_TELESERVICE_IMSST              = 4242,  /* IMS Services Teleservice */
  
    WMS_TELESERVICE_WAP_65002              = 65002,  /*WAP, FOR mms notification */
  
    /*---------------------------------------------------------------------
       The following are defined as extensions to the standard teleservices
    -----------------------------------------------------------------------*/
  
    /* teleservice types in Analog mode.
    */
    WMS_TELESERVICE_IS91_PAGE          = 0x00010000,
    WMS_TELESERVICE_IS91_VOICE_MAIL    = 0x00020000,
    WMS_TELESERVICE_IS91_SHORT_MESSAGE = 0x00030000,
  
    /* Voice mail notification through Message Waiting Indication in
       CDMA mode or Analog mode
    */
    WMS_TELESERVICE_MWI                = 0x00040000,
  
    /* Broadcast SMS messages
    */
    WMS_TELESERVICE_BROADCAST          = 0x00050000,
  
    WMS_TELESERVICE_UNKNOWN            = 0x0FFFFFFF

} wms_teleservice_e_type;

/* ------------------------ */
/* -- Service category ---- */
/* ------------------------ */
typedef enum
{
    WMS_SRV_UNKOWN          = 0,
    WMS_SRV_EMERGENCY,      // 1
    WMS_SRV_ADMIN,          // 2
    WMS_SRV_MAINTENANCE,    // 3
    WMS_SRV_GEN_NEWS_LOC,   // 4
    WMS_SRV_GEN_NEWS_REG,   // 5
    WMS_SRV_GEN_NEWS_NAT,   // 6
    WMS_SRV_GEN_NEWS_INT,   // 7
    WMS_SRV_FIN_NEWS_LOC,   // 8
    WMS_SRV_FIN_NEWS_REG,   // 9
    WMS_SRV_FIN_NEWS_NAT,   // 0xA
    WMS_SRV_FIN_NEWS_INT,   // 0xB
    WMS_SRV_SPT_NEWS_LOC,   // 0xC
    WMS_SRV_SPT_NEWS_REG,   // 0xD
    WMS_SRV_SPT_NEWS_NAT,   // 0xE
    WMS_SRV_SPT_NEWS_INT,   // 0xF
    WMS_SRV_ENT_NEWS_LOC,   // 0x10
    WMS_SRV_ENT_NEWS_REG,   // 0x11
    WMS_SRV_ENT_NEWS_NAT,   // 0x12
    WMS_SRV_ENT_NEWS_INT,   // 0x13
    WMS_SRV_LOC_WEATHER,    // 0x14
    WMS_SRV_AREA_TRAFFIC,   // 0x15
    WMS_SRV_AIRPORT_SCHED,  // 0x16
    WMS_SRV_RESTAURANTS,    // 0x17
    WMS_SRV_LODGINGS,       // 0x18
    WMS_SRV_RETAILS,        // 0x19
    WMS_SRV_ADS,            // 0x1A
    WMS_SRV_STOCK_QUOTES,   // 0x1B
    WMS_SRV_JOBS,           // 0x1C
    WMS_SRV_MEDICAL,        // 0x1D
    WMS_SRV_TECH_NEWS,      // 0x1E
    WMS_SRV_MULTI,          // 0x1F
  
    WMS_SRV_MAX32           = 0x10000000

} wms_service_e_type;

/* --------------------- */
/* ---- Error class ---- */
/* --------------------- */
typedef enum
{
    WMS_ERROR_NONE        = 0,
    WMS_ERROR_RESERVED_1  = 1,
    WMS_ERROR_TEMP        = 2,
    WMS_ERROR_PERM        = 3,
    WMS_ERROR_MAX32       = 0x10000000
  
} wms_error_class_e_type;

/* ---------------------- */
/* -- CDMA status code -- */
/* ---------------------- */
typedef enum
{
    /* The first half of the enums are from IS-41D SMS cause codes
       with the exact binary values as in IS-41D. They are in the range
       of 0x00 to 0xFF.
    */
  
    /* A. Network Problems:
    */
    WMS_TL_ADDRESS_VACANT_S                     = 0,
    WMS_TL_ADDRESS_TRANSLATION_FAILURE_S,
    WMS_TL_NETWORK_RESOURCE_SHORTAGE_S,
    WMS_TL_NETWORK_FAILURE_S,
    WMS_TL_INVALID_TELESERVICE_ID_S,
    WMS_TL_OTHER_NETWORK_PROBLEM_S,
    WMS_TL_OTHER_NETWORK_PROBLEM_MORE_FIRST_S   = 6,
    /* all values within this range are treated as
       WMS_TL_OTHER_NETWORK_PROBLEM_S
    */
    WMS_TL_OTHER_NETWORK_PROBLEM_MORE_LAST_S    = 31,
  
    /* B. Terminal Problems:
    */
    WMS_TL_NO_PAGE_RESPONSE_S                   = 32,
    WMS_TL_DESTINATION_BUSY_S,
    WMS_TL_NO_ACK_S,
    WMS_TL_DESTINATION_RESOURCE_SHORTAGE_S,
    WMS_TL_SMS_DELIVERY_POSTPONED_S,
    WMS_TL_DESTINATION_OUT_OF_SERVICE_S,
    WMS_TL_DESTINATION_NO_LONGER_AT_THIS_ADDRESS_S,
    WMS_TL_OTHER_TERMINAL_PROBLEM_S,
    WMS_TL_OTHER_TERMINAL_PROBLEM_MORE_FIRST_S  = 40,
    /* all values within this range are treated as
       WMS_TL_OTHER_TERMINAL_PROBLEM_S
    */
    WMS_TL_OTHER_TERMINAL_PROBLEM_MORE_LAST_S   = 47,
    WMS_TL_SMS_DELIVERY_POSTPONED_MORE_FIRST_S  = 48,
    WMS_TL_SMS_DELIVERY_POSTPONED_MORE_LAST_S   = 63,
  
    /* C. Radio Interface Problems:
    */
    WMS_TL_RADIO_IF_RESOURCE_SHORTAGE_S         = 64,
    WMS_TL_RADIO_IF_INCOMPATIBLE_S,
    WMS_TL_OTHER_RADIO_IF_PROBLEM_S,
    WMS_TL_OTHER_RADIO_IF_PROBLEM_MORE_FIRST_S  = 67,
    /* all values within this range are treated as
       WMS_TL_OTHER_RADIO_IF_PROBLEM_S
    */
    WMS_TL_OTHER_RADIO_IF_PROBLEM_MORE_LAST_S   = 95,
  
    /* D. General Problems:
    */
    WMS_TL_UNEXPECTED_PARM_SIZE_S               = 96,
    WMS_TL_SMS_ORIGINATION_DENIED_S,
    WMS_TL_SMS_TERMINATION_DENIED_S,
    WMS_TL_SUPPL_SERVICE_NOT_SUPPORTED,
    WMS_TL_SMS_NOT_SUPPORTED_S,
    WMS_TL_RESERVED_101_S,
    WMS_TL_MISSING_EXPECTED_PARM_S,
    WMS_TL_MISSING_MANDATORY_PARM_S,
    WMS_TL_UNRECOGNIZED_PARM_VALUE_S,
    WMS_TL_UNEXPECTED_PARM_VALUE_S,
    WMS_TL_USER_DATA_SIZE_ERROR_S,
    WMS_TL_OTHER_GENERAL_PROBLEMS_S,
    WMS_TL_OTHER_GENERAL_PROBLEMS_MORE_FIRST_S  = 108,
    /* all values within this range are treated as
       WMS_TL_OTHER_GENERAL_PROBLEMS_S
    */
    WMS_TL_OTHER_GENERAL_PROBLEMS_MORE_LAST_S   = 255,
    WMS_TL_MAX32                                = 0x10000000

} wms_cdma_tl_status_e_type;

/* Cause code
*/
typedef struct
{
    unsigned char reply_seq_num;
    wms_error_class_e_type    error_class;
  
    /* If error_class is NoError, status should be ignored.
       Only the first half of the enums are used in this structure.
    */
    wms_cdma_tl_status_e_type tl_status;
} wms_cause_code_type;

/*============================================================================

FUNCTION B_PACKB

DESCRIPTION
  Packs the given byte into the destination at the given offset for the
  given number of length bits

DEPENDENCIES
  None
   
RETURN VALUE
  None

SIDE EFFECTS
  None
   
============================================================================*/
void b_packb(
   unsigned char src, 
   unsigned char dst[], 
   unsigned short pos, 
   unsigned short len 
)
{
   unsigned short   t_pos = pos % 8;
   unsigned short   bits  = 8 - t_pos;

   dst += (pos+len-1)/8;

   if ( bits >= len )
   {
       *dst &= (unsigned char) ~MASK_B(t_pos, len);
       *dst |= (unsigned char) (MASK_B(t_pos, len) & (src << (bits - len)));
   }
   else /* len > bits */
   {
       dst--;
       *dst &= (unsigned char) ~MASK_B(t_pos, bits);
       *dst |= (unsigned char) (MASK_B(t_pos, bits) & (src >> (len - bits)));

       dst++;
       *dst &= (unsigned char) ~MASK_B(0, (len - bits));
       *dst |= (unsigned char) (MASK_B(0, (len - bits)) & (src << (8 - (len - bits))));
   }
} /* END b_packb */

/*============================================================================

FUNCTION B_PACKW

DESCRIPTION
  Packs the given word into the destination at the given offset for the
  given number of length bits

DEPENDENCIES
  None
   
RETURN VALUE
  None

SIDE EFFECTS
  None
   
============================================================================*/
void b_packw(
   unsigned short src, 
   unsigned char dst[], 
   unsigned short pos, 
   unsigned short len 
)
{
   int bits, start;
   unsigned char   mask;
 
   dst += (len+pos-1)/8;        /* point to last byte to be written */
   pos  = (len+pos-1)%8;        /* index of last bit to be written */
   
   if (len > pos)  /* if we are filling all of the left part of the byte */
   {
     start = 0;  
   }
   else            /* There are going to be untouched bits at left of 
                   ** destination byte.                                   */
   {
     start = (pos+1) - len;     
   }
   bits = (pos - start) + 1;    /* # of bits to be written in this byte */
   
   *dst &= (unsigned char) ~MASK_B(start,bits);  /* clear the bits to be written */
   
   *dst |= (unsigned char) (   ( src << (7 - pos) )    /* left-shift src to line up */
                    & MASK_B(start, bits) );  /* only touch desired bits */
   
   dst--;                /* back up one byte */
   src >>= bits;         /* get rid of bits we've consumed already */
   
   if(len > bits)        /* if we need to write into other bytes */
   {
     len -= bits;        /* compute remaining length  */
     
     /* for full bytes, we can just overwrite the old value with the new */
     for ( ; len >= 8 ; len -= 8 ) {
       *dst = (unsigned char)( src );
       dst--;                         /* back up one byte */
       src >>= 8;                     /* get rid of used bits */
     }
 
     if (len > 0)     /* if some bits are leftover... */
     {
       mask = (unsigned char) (0xff << len);   
       *dst &= mask;                  /* clear bits on right side of byte */
       *dst |= ( (unsigned char)( src ) & ~mask);        /* set appropriate bits */
     }
 
   }
} /* END b_packw */

/*============================================================================

FUNCTION B_UNPACKB

DESCRIPTION
  Given a buffer and an offset, unpacks the requested number of bits into
  a byte

DEPENDENCIES
  None
   
RETURN VALUE
  Unpacked item

SIDE EFFECTS
  None
   
============================================================================*/
unsigned char b_unpackb(
   unsigned char *src, 
   unsigned short pos, 
   unsigned short len
)
{
   unsigned char result = 0;
   int rshift = 0;

   src += pos/8;
   pos %= 8;
   
   rshift = MAX( 8 - (pos + len), 0);

   if ( rshift > 0 ) {

     result = MASK_AND_SHIFT(len, pos, rshift, *src);
  
   } else {

     result = MASK(8-pos, pos, *src);
     src++;
     len -= 8 - pos;

      if ( len > 0 ) result = ( result<<len ) | (*src >> (8-len));  // if any bits left
   }

   return result;
} /* END b_unpackb */

/*============================================================================

FUNCTION B_UNPACKW

DESCRIPTION
  Given a buffer and an offset, unpacks the requested number of bits into
  a word

DEPENDENCIES
  None
   
RETURN VALUE
  Unpacked item

SIDE EFFECTS
  None
   
============================================================================*/
unsigned short b_unpackw(
   unsigned char src[], 
   unsigned short pos, 
   unsigned short len
)
{ 
   unsigned short result = 0;
   int rshift = 0;

   src += pos/8;
   pos %= 8;

   rshift = MAX( 8 - (pos + len), 0);

   ALOGD("b_unpackw pos %d, rshift %d", pos, rshift);

   if ( rshift > 0 ) {

     result = MASK_AND_SHIFT(len, pos, rshift, *src);
  
   } else {

      result = MASK(8-pos, pos, *src);
      src++;
      len -= 8 - pos;

      ALOGD("b_unpackw result %d, len %d", result, len);

      for ( ; len >= 8  ; len-=8)
      {
         result = ( result<<8 ) | *src++;
      }

      if ( len > 0 ) result = ( result<<len ) | (*src >> (8-len));  // if any bits left
   }

   ALOGD("b_unpackw result %d", result);

   return result;
} /* END b_unpackw */

/*===========================================================================

FUNCTION    simcom_sms_convert_hex_to_bin

DESCRIPTION
  Takes a Hex stream (Given in ASCII format) and converts it to stream of 
  octets. Ex. "2A" is converted to 42.
  
DEPENDENCIES
  None

RETURN VALUE

SIDE EFFECTS
  None
===========================================================================*/
int simcom_sms_convert_hex_to_bin
(
    unsigned char * in_ptr,    /* Pointer to the Hex data (in ASCII format)    */ 
    unsigned char * out_ptr,   /* Pointer to the result buffer(converted data) */
    int     len        /* Length of the input data pointer (Hex data)  */
)
{
    unsigned char *s;
    unsigned char *end;
    unsigned char *out_pos;    
    unsigned char temp_buf[3];
    long l;    
    int len_left = len;    
    int i;
    int result = 0;
  
    s = in_ptr;
  
    len_left = len_left * 2;
    out_pos = out_ptr;
    while(len_left > 0)
    {
        for (i=0; (i<2) && (*s != '\0'); i++)
        {
            temp_buf[i] = *s++;
        }
        temp_buf[i] = '\0';
        *out_pos++ = strtoul((const char *)temp_buf, (char **)&end, 16);
        if (end == temp_buf)
        {
            /* We got a out of range value */
            result = -1;
            break;
        }
        len_left -= i;
    }
    *out_pos = '\0';

    {
        char *dbg_data[512];
        char *dbg_pos;
        int i;

        dbg_pos = dbg_data;
        for(i = 0; i < len; i++)
        {
            dbg_pos += sprintf(dbg_pos, "%02x", out_ptr[i]);
        }
        *dbg_pos = '\0';
        
        ALOGD("simcom_sms_convert_hex_to_bin <%s> to <%s>", in_ptr, dbg_data);
    }
    
    return result;
} /* dsatetsismsi_encode_pdu */

/*===========================================================================

FUNCTION    simcom_sms_convert_bin_to_hex

DESCRIPTION
  Takes a BIN data and converts it to Hex stream (Given in ASCII format) . Ex. 0x2A is converted to "2A".
  
DEPENDENCIES
  None

RETURN VALUE

SIDE EFFECTS
  None
===========================================================================*/
int simcom_sms_convert_bin_to_hex
(
    unsigned char * in_ptr,    /* Pointer to the BIN data */
    unsigned char * out_ptr,   /* Pointer to the Hex data (in ASCII format)    */ 
    int     len        /* Length of the input data pointer (Bin data)  */
)
{
    unsigned char data;
    unsigned char *out_pos;   
    int result = 0;
    int i;

    out_pos = out_ptr;
    for(i = 0; i < len; i++)
    {
        data = (in_ptr[i] >> 4 ) & 0x0f;
        *out_pos++ = (data >= 10) ? ('A' + data - 10) : ('0' + data);
        data = in_ptr[i] & 0x0f;
        *out_pos++ = (data >= 10) ? ('A' + data - 10) : ('0' + data);
    }
    *out_pos = '\0';
    
    {
        char *dbg_data[600];
        char *dbg_pos;

        dbg_pos = dbg_data;
        for(i = 0; i < len; i++)
        {
            dbg_pos += sprintf(dbg_pos, "%02x", in_ptr[i]);
        }
        *dbg_pos = '\0';
        
        ALOGD("simcom_sms_convert_bin_to_hex <%s> to <%s>", dbg_data, out_ptr);
    }

    
    return result;
} /* dsatetsismsi_encode_pdu */

wms_status_e_type simcom_cdma_decode_address
(
    const unsigned char                 * data,
    unsigned char                 parm_len,
    RIL_CDMA_SMS_Address    * address_ptr
)
{
    unsigned long     bit_pos = 0;
    unsigned char      digit_size;
    wms_status_e_type   st = WMS_OK_S;
    unsigned long       i;
  
    /*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
  
      /*---- checking ---- */
    if ( address_ptr == NULL || data == NULL)
    {
        ALOGE("simcom_cdma_decode_address null ptr!");
        return WMS_NULL_PTR_S;
    }
  
  
    /* Digit mode */
    address_ptr->digit_mode = (RIL_CDMA_SMS_DigitMode)
                    b_unpackb( (unsigned char*) data, (unsigned short) (bit_pos), 1 );
    bit_pos ++;
  
    /* Number mode */
    address_ptr->number_mode = (RIL_CDMA_SMS_NumberMode)
                 b_unpackb( (unsigned char*) data, (unsigned short) (bit_pos), 1 );
    bit_pos ++;
  
  
    /* Number type, and determine digit size */
    if( address_ptr->digit_mode == RIL_CDMA_SMS_DIGIT_MODE_8_BIT )
    {
        address_ptr->number_type = (RIL_CDMA_SMS_NumberType)
                        b_unpackb( (unsigned char*) data, (unsigned short) (bit_pos), 3 );
        bit_pos += 3;
    
        digit_size = 8;
    }
    else
    {
        address_ptr->number_type = RIL_CDMA_SMS_NUMBER_TYPE_UNKNOWN;
        digit_size = 4;
    }
  
  
    /* Number plan */
    if( address_ptr->digit_mode  == RIL_CDMA_SMS_DIGIT_MODE_8_BIT &&
        address_ptr->number_mode == RIL_CDMA_SMS_NUMBER_MODE_NOT_DATA_NETWORK )
    {
        address_ptr->number_plan = (RIL_CDMA_SMS_NumberPlan)
                    b_unpackb( (unsigned char*) data, (unsigned short) (bit_pos), 4);
        bit_pos += 4;
    }
    else
    {
        /* number plan is not used */
        address_ptr->number_plan = RIL_CDMA_SMS_NUMBER_PLAN_UNKNOWN;
    }
  
    /* Address size */
    address_ptr->number_of_digits=
                      b_unpackb( (unsigned char*) data, (unsigned short) (bit_pos), 8 );
    bit_pos += 8;
  
  
    /* Extract all digits:
    */
    if( address_ptr->number_of_digits > RIL_CDMA_SMS_ADDRESS_MAX )
    {
        ALOGD( "decoding: address digits number too big: %d", address_ptr->number_of_digits);
        st = WMS_INVALID_PARM_SIZE_S;
    }
    else
    {
        for( i=0; i < address_ptr->number_of_digits; i++ )
        {
            address_ptr->digits[i] = b_unpackb( (unsigned char*) data,
                                                         (unsigned short) (bit_pos),
                                                         digit_size );
            bit_pos += digit_size;
        }
    }
  
    /* Parm len checking */
    if( bit_pos > (unsigned long)(parm_len*8) )
    {
        ALOGD( "decoding: address too long: %d>%d", (int)bit_pos, (int)parm_len*8 );
        st = WMS_INVALID_PARM_SIZE_S;
    }
  
    return st;

} /* simcom_cdma_decode_address() */

/*
*/
wms_status_e_type simcom_cdma_decode_subaddress
(
    const unsigned char                 * data,
    unsigned char                 parm_len,
    RIL_CDMA_SMS_Subaddress    * address_ptr
)
{
    unsigned long     bit_pos = 0;
    unsigned char      digit_size;
    wms_status_e_type   st = WMS_OK_S;
    unsigned long       i;
  
    /*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
  
    /*---- checking ---- */
    if ( address_ptr == NULL || data == NULL)
    {
        ALOGE("simcom_cdma_decode_subaddress null ptr!");
        return WMS_NULL_PTR_S;
    }
  
  
    /* address type */
    address_ptr->subaddressType = (RIL_CDMA_SMS_SubaddressType)
                    b_unpackb( (unsigned char*) data, (unsigned short) (bit_pos), 3 );
    bit_pos += 3;
  
    /* Odd flag */
    address_ptr->odd = b_unpackb( (unsigned char*) data, (unsigned short) (bit_pos), 1 );
    bit_pos += 1;
  
    /* Address size */
    address_ptr->number_of_digits = b_unpackb( (unsigned char*) data, (unsigned short) (bit_pos), 8 );
    bit_pos += 8;
  
    /* Extract all digits:
    */
    if( address_ptr->number_of_digits > RIL_CDMA_SMS_SUBADDRESS_MAX )
    {
        ALOGD( "decoding: subaddress digits number too big: %d", address_ptr->number_of_digits);
        st = WMS_INVALID_PARM_SIZE_S;
    }
    else
    {
        digit_size = 8;  /* always 8 bits so far */
    
        for( i=0; i < address_ptr->number_of_digits; i++ )
        {
            address_ptr->digits[i] = b_unpackb( (unsigned char*) data,
                                                        (unsigned short) (bit_pos),
                                                        digit_size );
            bit_pos += digit_size;
        }
    }
  
    /* parm len check */
    if( bit_pos > (unsigned long)(parm_len*8) )
    {
        ALOGD( "decoding: subaddress too long: %d>%d", (int)bit_pos, (int)parm_len*8);
        st = WMS_INVALID_PARM_SIZE_S;
    }
  
    /* Done */
    return st;

} /* simcom_cdma_decode_subaddress() */

/*
*/
wms_status_e_type simcom_cdma_encode_address
(
    const RIL_CDMA_SMS_Address  * address_ptr,
    unsigned char               * parm_len_ptr,
    unsigned char               * data
)
{
    unsigned long       bit_pos = 0;
    wms_status_e_type  st = WMS_OK_S;
    unsigned char        digit_size;
    unsigned long       i;
  
    /*---- checking ---- */
    if ( address_ptr == NULL || parm_len_ptr == NULL || data == NULL)
    {
        ALOGE("simcom_cdma_encode_address null ptr!");
        return WMS_NULL_PTR_S;
    }
  
    /* Digit Mode */
    b_packb( (unsigned char) address_ptr->digit_mode,
             data,
             (unsigned short) (bit_pos),
             1 );
    bit_pos++;
  
    /* Number mode */
    b_packb( (unsigned char) address_ptr->number_mode,
             data,
             (unsigned short) (bit_pos),
             1 );
    bit_pos++;
  
    /* Number type */
    if( address_ptr->digit_mode == RIL_CDMA_SMS_DIGIT_MODE_8_BIT )
    {
        digit_size = 8;
    
        b_packb( (unsigned char) address_ptr->number_type,
                 data,
                 (unsigned short) (bit_pos),
                 3 );
        bit_pos += 3;
    
        if( address_ptr->number_mode == RIL_CDMA_SMS_NUMBER_MODE_DATA_NETWORK )
        {
            b_packb( (unsigned char) address_ptr->number_plan,
                     data,
                     (unsigned short) (bit_pos),
                     4 );
            bit_pos += 4;
        }
    }
    else
    {
        digit_size = 4;
    }
  
    /* Address size */
    b_packb( address_ptr->number_of_digits,
             data,
             (unsigned short) (bit_pos),
             8 );
    bit_pos += 8;
  
    /* pack the digits */
    for( i= 0; i < address_ptr->number_of_digits; i ++ )
    {
        b_packb( address_ptr->digits[i],
                 data,
                 (unsigned short) (bit_pos),
                 digit_size );
        bit_pos += digit_size;
    }
  
    if( bit_pos % 8 != 0 )
    {
        /* pad 0 to remaining bits
        */
        digit_size = (unsigned char)(8 - bit_pos % 8);
        b_packb( 0, data, (unsigned short) (bit_pos),  digit_size );
        bit_pos += digit_size;
    }
  
    *parm_len_ptr = (unsigned char) (bit_pos/8);
  
    return st;
} /* simcom_cdma_encode_address() */


/*
*/
wms_status_e_type simcom_cdma_encode_subaddress
(
    const RIL_CDMA_SMS_Subaddress  * address_ptr,
    unsigned char                  * parm_len_ptr,
    unsigned char                  * data
)
{
    unsigned long             bit_pos = 0;
    wms_status_e_type  st = WMS_OK_S;
    unsigned char              digit_size;
    unsigned long       i;
  
    /*---- checking ---- */
    if ( address_ptr == NULL || parm_len_ptr == NULL || data == NULL)
    {
        ALOGE("simcom_cdma_encode_subaddress null ptr!");
        return WMS_NULL_PTR_S;
    }
  
    /* subaddress type */
    b_packb( (unsigned char) address_ptr->subaddressType,
             data,
             (unsigned short) (bit_pos),
             3 );
    bit_pos += 3;
  
    /* Odd flag */
    b_packb( address_ptr->odd,
             data,
             (unsigned short) (bit_pos),
             1 );
    bit_pos += 1;
  
    /* Address size */
    b_packb( address_ptr->number_of_digits,
             data,
             (unsigned short) (bit_pos),
             8 );
    bit_pos += 8;
  
    /* Digit size */
    digit_size = 8;  /* always 8 */
  
    /* Pack the digits */
    for( i=0; i < address_ptr->number_of_digits; i++ )
    {
        b_packb( address_ptr->digits[i],
                 data,
                 (unsigned short) (bit_pos),
                 digit_size );
        bit_pos += digit_size;
    }
  
    /* pad last 4 bits with 0 */
    b_packb( 0,
             data,
             (unsigned short) (bit_pos),
             4 );
    bit_pos += 4;
  
    /* return len */
    * parm_len_ptr = (unsigned char) (bit_pos/8);
  
    return st;

} /* wms_ts_cdma_encode_subaddress() */


/*===========================================================================

FUNCTION simcom_cdma_decode_sms

DESCRIPTION
    Decode a CDMA SMS Message
  
PARAMETERS
    [in] encoded_sms -  the sms to encode
    [out] msg  -    the sms PDU

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
RIL_Errno simcom_cdma_decode_sms (
    RIL_CDMA_Encoded_SMS * encoded_sms,   /* Input */
    RIL_CDMA_SMS_Message * msg      /* Output */
)
{
    RIL_Errno ret = RIL_E_GENERIC_FAILURE;
    unsigned char msg_data[RIL_CDMA_SMS_BEARER_DATA_MAX];
    wms_tl_message_type_e_type tl_message_type;
    wms_status_e_type       st = WMS_OK_S;    
    int pos;
    wms_tl_parm_id_e_type parm_id = WMS_TL_DUMMY;
    unsigned char parm_len;
    unsigned short tl_len;  /* len of TL data */
    unsigned int mask;  /* the mask indicates which fields are present in this message */
    int is_mo = 0;
    unsigned char bearer_reply_seq_num; /* 0..63 */
    wms_cause_code_type cause_code;

    if(!encoded_sms || !msg)
    {
        ALOGE("simcom_cdma_decode_sms invalid parameter!");    
        goto Error;
    }

    if(simcom_sms_convert_hex_to_bin(encoded_sms->data, msg_data, encoded_sms->length / 2) < 0)
    {
        ALOGE("simcom_cdma_decode_sms simcom_sms_convert_hex_to_bin failed!");    
        goto Error;
    }

    /* ---- start decoding ---- */
    memset(msg, 0, sizeof(msg));
    mask = 0;    
    pos = 0;
    tl_len = encoded_sms->length / 2;
    
    /* the first byte is msg type */    
    if(msg_data[pos] > (unsigned char) WMS_TL_TYPE_MAX)
    {
        ALOGE("simcom_cdma_decode_sms invalid TL msg type: %d!", msg_data[pos]);        
        goto Error;
    }
    tl_message_type = (wms_tl_message_type_e_type)msg_data[pos];
    pos++;

    ALOGD("simcom_cdma_decode_sms tl_message_type %d", tl_message_type);    

    /* the remain data has one or more of the following:
       - PARAMETER_ID    8 bits
       - PARAMETER_LEN   8 bits
       - Parameter Data  8 x PARAMETER_LEN
    */

    while( st == WMS_OK_S  )
    {
        if( pos == tl_len )
        {
            /* Good. Done with parameter processing successfully */
            break; /* out of while loop */
        }
        else if( pos + TL_PARM_SIZE > tl_len )
        {
            /* Oops. Current position goes beyond the msg size. */
            ALOGE( "decoding: parameter (id=%d) extends beyond msg size %d",  parm_id, tl_len);
            st = WMS_INVALID_PARM_SIZE_S;
            break; /* out of while loop */
        }

        ALOGD("simcom_cdma_decode_sms pos %d", pos);    

        parm_id = (wms_tl_parm_id_e_type) ( msg_data[ pos ] );
        pos ++;  /* skip parm id */
    
        parm_len = msg_data[ pos ];
        pos ++;  /* skip parm len */
    
        if( pos + parm_len > tl_len )
        {
            /* parm data passes the max length of bearer data
            */
            ALOGE( "decoding: parameter (id=%d) extends beyond msg size %d", parm_id, tl_len);
            st = WMS_INVALID_PARM_SIZE_S;
            break; /* out of while loop */
        }

        ALOGD("simcom_cdma_decode_sms pos %d, para_id %d, parm_len %d", pos, parm_id, parm_len);    
    
        /* Now pos should point to the parm data */
        /* After each case below, pos should point to the next parm Id */
        switch( parm_id )
        {
          case WMS_TL_TELESERVICE_ID:
            if( mask & WMS_MASK_TL_TELESERVICE_ID )
            {
                pos += parm_len;    /* skip parm data */
                break;              /* continue with next parm */
            }
    
            mask |= WMS_MASK_TL_TELESERVICE_ID;
    
            if( pos  + 2 > tl_len || parm_len != 2)
            {
                /* tl data too short , or bad len field */
                st = WMS_INVALID_PARM_SIZE_S;
            }
            else
            {
                msg->uTeleserviceID = b_unpackw( (unsigned char*) msg_data,
                                                                  (unsigned short) (pos*8),
                                                                  parm_len*8 );
                pos += parm_len; /* skip parm data */
            }

            ALOGD("simcom_cdma_decode_sms uTeleserviceID %d, pos %d", msg->uTeleserviceID, pos);    
            
            break;
            case WMS_TL_BC_SRV_CATEGORY:
    
            if( mask & WMS_MASK_TL_BC_SRV_CATEGORY )
            {
                pos += parm_len;    /* skip parm data */
                break;              /* continue with next parm */
            }
    
    
            mask |= WMS_MASK_TL_BC_SRV_CATEGORY;
    
            if( pos  + 2 > tl_len ||
                parm_len != 2
              )
            {
                /* tl data too short , or bad len field */
                st = WMS_INVALID_PARM_SIZE_S;
            }
            else
            {
                msg->uServicecategory = (wms_service_e_type)b_unpackw( (unsigned char*) msg_data,
                                           (unsigned short) (pos*8),
                                             parm_len*8 );
                pos += parm_len; /* skip parm data */
            }

            ALOGD("simcom_cdma_decode_sms uServicecategory %d, pos %d", msg->uServicecategory, pos);    
    
            break;
    
          case WMS_TL_ORIG_ADDRESS:
          case WMS_TL_DEST_ADDRESS:
    
            if( mask & WMS_MASK_TL_ADDRESS )
            {
              pos += parm_len;    /* skip parm data */
              break;              /* continue with next parm */
            }
    
            mask |= WMS_MASK_TL_ADDRESS;
    
            /* Set the MO/MT tag. */
            is_mo = ( parm_id == WMS_TL_DEST_ADDRESS ) ? 1 : 0;
    
            st = simcom_cdma_decode_address( (unsigned char*) msg_data+pos,
                                             parm_len,
                                             & msg->sAddress);
            pos += parm_len;

            ALOGD("simcom_cdma_decode_sms dest addr pos %d, addr(%d, %d, %d, %d, %s)", pos, msg->sAddress.digit_mode, msg->sAddress.number_mode, 
                msg->sAddress.number_type, msg->sAddress.number_of_digits, msg->sAddress.digits);    
            
            break;
    
          case WMS_TL_ORIG_SUBADDRESS:
          case WMS_TL_DEST_SUBADDRESS:
    
            if( mask & WMS_MASK_TL_SUBADDRESS )
            {
                pos += parm_len;    /* skip parm data */
                break;              /* continue with next parm */
            }
    
            mask |= WMS_MASK_TL_SUBADDRESS;
    
            /* Set the MO/MT tag. */
            is_mo = ( parm_id == WMS_TL_DEST_SUBADDRESS ) ? 1 : 0;
    
            st = simcom_cdma_decode_subaddress( (unsigned char*) msg_data+pos,
                                                parm_len,
                                                & msg->sSubAddress);
            pos += parm_len;  /* skip parm data */

            ALOGD("simcom_cdma_decode_sms dest subaddr pos %d, addr(%d, %d, %d, %s)", pos, msg->sSubAddress.subaddressType, msg->sSubAddress.odd, 
                msg->sSubAddress.number_of_digits, msg->sSubAddress.digits);
            
            break;
    
          case WMS_TL_BEARER_REPLY_OPTION:
    
            if( mask & WMS_MASK_TL_BEARER_REPLY_OPTION )
            {
                pos += parm_len;    /* skip parm data */
                break;              /* continue with next parm */
            }
    
            mask |= WMS_MASK_TL_BEARER_REPLY_OPTION;
    
            if( parm_len != 1 )
            {
                ALOGE("decoding: bearer reply option len is not 1: %d. Reset to 1.", parm_len);
                goto Error;
            }
    
            bearer_reply_seq_num = msg_data[pos] >> 2;
              /* get high 6 bits */
    
            pos += parm_len; /* skip parm data */

            ALOGD("simcom_cdma_decode_sms bearer_reply_seq_num %d, pos %d", bearer_reply_seq_num, pos);    
    
            break;
    
          case WMS_TL_CAUSE_CODES:
    
            if( mask & WMS_MASK_TL_CAUSE_CODES )
            {
                pos += parm_len;    /* skip parm data */
                break;              /* continue with next parm */
            }
    
    
            mask |= WMS_MASK_TL_CAUSE_CODES;
    
            cause_code.reply_seq_num = msg_data[pos] >> 2;
              /* get high 6 bits */
            cause_code.error_class = (wms_error_class_e_type) (msg_data[pos] & 0x03);
              /* get low 2 bits */
    
            pos ++; /* skip first parm data byte */
    
            if( parm_len == 1 )
            {
                /* If parm_len==1, error_class shall be NONE */
                if( cause_code.error_class != WMS_ERROR_NONE)
                {
                    ALOGE("decoding: invalid parm len = 1 with valid error cause identifier");
                    st = WMS_INVALID_PARM_SIZE_S;
                }
            }
            else if( parm_len == 2 )
            {
                cause_code.tl_status = (wms_cdma_tl_status_e_type)msg_data[pos];
                pos ++; /* skip cause code in parm data */
            }
            else
            {
                ALOGE("decoding: invalid parm len for CauseCodes: %d", parm_len);
                st = WMS_INVALID_PARM_SIZE_S;
            }
    
            break;
    
    
          case WMS_TL_BEARER_DATA:
    
            if( mask & WMS_MASK_TL_BEARER_DATA )
            {
                pos += parm_len;    /* skip parm data */
                break;              /* continue with next parm */
            }
    
    
            /* bearer data is not decoded here */
            /* it will be copied to the output */
    
            mask |= WMS_MASK_TL_BEARER_DATA;
    
            if( parm_len == 0 )
            {
                ALOGE("decoding: bearer data len is 0");
                st = WMS_INVALID_PARM_SIZE_S;
            }
            /* parm_len is unsigned char, so it won't be greater than WMS_MAX_LEN */
            else if( pos + parm_len > tl_len )
            {
                ALOGE("decoding: bearer data len %d extends beyond msg size %d", parm_len, tl_len);
                st = WMS_INVALID_PARM_SIZE_S;
            }
            else
            {
                /* copy bearer data to output
                */
                msg->uBearerDataLen = MIN (parm_len, RIL_CDMA_SMS_BEARER_DATA_MAX);
                memcpy( msg->aBearerData, (unsigned char*)msg_data + pos, msg->uBearerDataLen );
            }
    
            pos += parm_len; /* skip parm data */

            ALOGD("simcom_cdma_decode_sms aBearerData <%s>, pos %d", msg->aBearerData, pos);    
    
            break;
    
          default:
            ALOGE( "decoding: Invalid parm id: %d", parm_id);
            pos += parm_len; /* skip parm data */
            break;           /* continue with next parm */
    
        } /* switch */
    } /* while */


    /* Null the raw bd */
    if( ! ( mask & WMS_MASK_TL_BEARER_DATA ) )
    {
        msg->uBearerDataLen = 0;
    }

    ALOGD("simcom_cdma_decode_sms st <%d>, tl_message_type %d, mask 0x%x", st, tl_message_type, mask);    
  
    /* -------- check CDMA TL mandatory fields -------- */
    if( st == WMS_OK_S)
    {
        switch( tl_message_type )
        {
          case WMS_TL_TYPE_POINT_TO_POINT:
            if( ! ( mask & WMS_MASK_TL_ADDRESS ) )
            {
                ALOGD("No address present in msg!");
                st = WMS_MISSING_PARM_S;
            }
            break;
    
          case WMS_TL_TYPE_BROADCAST:
    
            if( ! ( mask & WMS_MASK_TL_BC_SRV_CATEGORY ) )
            {
                ALOGD( "decoding: broadcast category is not present!");
                st = WMS_MISSING_PARM_S;
            }
            break;
    
          case WMS_TL_TYPE_ACK:
            if( ! ( mask & WMS_MASK_TL_CAUSE_CODES ) )
            {
                ALOGD( "decoding: cause code is not present in Ack!");
                st = WMS_MISSING_PARM_S;
            }
            break;
    
          default:
            ALOGD( "decoding: invalid TL msg type: %d", tl_message_type);
            st = WMS_INVALID_PARM_VALUE_S;
            break;
        } /* switch */
    }

    ret = RIL_E_SUCCESS;

Error:

    return ret;
}

/*===========================================================================

FUNCTION simcom_cdma_encode_sms

DESCRIPTION
    Encode a CDMA SMS Message
  
PARAMETERS
    [in] msg  -    the sms PDU
    [out] encoded_sms -  the sms to encode

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
RIL_Errno simcom_cdma_encode_sms (
    RIL_CDMA_SMS_Message * msg,     /* Input */
    RIL_CDMA_Encoded_SMS * encoded_sms    /* Output */
)
{
    RIL_Errno ret = RIL_E_GENERIC_FAILURE;
    unsigned short pos = 0;
    unsigned char parm_len;
    unsigned char * parm_len_ptr;
    unsigned char data[RIL_CDMA_SMS_BEARER_DATA_MAX];
    wms_status_e_type   st = WMS_OK_S;
    int len;

    /*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
  
    /*---- checking ---- */
    if ( msg == NULL || encoded_sms == NULL)
    {
        ALOGE("simcom_cdma_encode_sms invalid parameter!");    
        goto Error;
    }
  
    ALOGD("simcom_cdma_encode_sms uTeleserviceID %d", msg->uTeleserviceID);    
    {
        /* For the following special cases, there is TL information and raw_bd_ptr
        ** has the OTA data ready
        */
        if( msg->uTeleserviceID == WMS_TELESERVICE_MWI ||
            msg->uTeleserviceID == WMS_TELESERVICE_IS91_PAGE ||
            msg->uTeleserviceID == WMS_TELESERVICE_IS91_VOICE_MAIL ||
            msg->uTeleserviceID == WMS_TELESERVICE_IS91_SHORT_MESSAGE )
        {
            len = (unsigned short) MIN (msg->uBearerDataLen, RIL_CDMA_SMS_BEARER_DATA_MAX);
            if(simcom_sms_convert_bin_to_hex(msg->aBearerData, encoded_sms->data, len) < 0)
            {
                ALOGE( "simcom_cdma_encode_sms convert to hex failed!");
                goto Error;
            }
            encoded_sms->length = 2 * len;
            return RIL_E_SUCCESS; /* RETURN */
        }

        ALOGD("simcom_cdma_encode_sms sms type pos %d", pos);    
    
        /* msg type
        */
        data[0] = (unsigned char)WMS_TL_TYPE_POINT_TO_POINT;
        pos ++;
    
        /* the remaining parameters have one or more of the following:
           - PARAMETER_ID    8 bits
           - PARAMETER_LEN   8 bits
           - Parameter Data  8 x PARAMETER_LEN
        */
        data[pos] = (unsigned char) WMS_TL_TELESERVICE_ID;
        pos++; /* skip parm id */
        
        data[pos] = parm_len = 2;
        pos++; /* skip len */
        
        b_packw( (unsigned short) msg->uTeleserviceID,
                 data,
                 (unsigned short) (pos * 8),
                 parm_len * 8 );
        
        pos += parm_len;  /* skip parm data */

        #if 0
                ALOGD("simcom_cdma_encode_sms bc srv category pos %d, uServicecategory %d", pos, msg->uServicecategory);    
            
                data[pos] = (unsigned char) WMS_TL_BC_SRV_CATEGORY;
                pos++; /* skip parm id */
                
                data[pos] = parm_len = 2;
                pos++; /* skip len */
                
                b_packw( (unsigned short) (msg->uServicecategory),
                         data,
                         (unsigned short) (pos * 8),
                         parm_len * 8 );
                
                pos += parm_len;  /* skip parm data */
        #endif

        ALOGD("simcom_cdma_encode_sms dest addr pos %d, addr(%d, %d, %d, %d, %s)", pos, msg->sAddress.digit_mode, msg->sAddress.number_mode, 
            msg->sAddress.number_type, msg->sAddress.number_of_digits, msg->sAddress.digits);    
        
        data[pos] = WMS_TL_DEST_ADDRESS;
        pos++; /* skip parm id */
        
        parm_len_ptr = data + pos;   /* will set value later */
        pos ++; /* skip parm len */
        
        st = simcom_cdma_encode_address( & msg->sAddress,
                                         parm_len_ptr,
                                         data+pos );
        pos += * parm_len_ptr; /* skip parm data */

        ALOGD("simcom_cdma_encode_sms dest subaddr pos %d, addr(%d, %d, %d, %s)", pos, msg->sSubAddress.subaddressType, msg->sSubAddress.odd, 
            msg->sSubAddress.number_of_digits, msg->sSubAddress.digits);
    
        data[pos] = WMS_TL_DEST_SUBADDRESS;
        pos++; /* skip parm id */
        
        parm_len_ptr = data + pos;   /* will set value later */
        pos ++; /* skip parm len */
        
        st = simcom_cdma_encode_subaddress( & msg->sSubAddress,
                                            parm_len_ptr,
                                            data+pos );
        pos += * parm_len_ptr;
  
        #if 0
        data[pos] = (unsigned char) WMS_TL_BEARER_REPLY_OPTION;
        pos++; /* skip parm id */
        
        data[pos] = parm_len = 1;
        pos++;
        
        b_packb(bearer_reply_seq_num,
                 data,
               (unsigned short) (pos * 8),
                 6 );  /* high 6 bits */
        
        b_packb( 0,
                 data,
               (unsigned short) (pos * 8 + 6),
                 2 );  /* low 2 bits: reserved, set to 0 */
        
        pos += parm_len;  /* skip parm data */
    
        data[pos] = (unsigned char) WMS_TL_CAUSE_CODES;
        pos++; /* skip parm id */
        
        data[pos] = (cause_code.error_class==WMS_ERROR_NONE)?
                    1 : 2;
        pos++; /* skip parm len */
        
        b_packb( cause_code.reply_seq_num,
                 data,
               (unsigned short) (pos * 8),
                 6 );  /* high 6 bits */
        
        /* TBD: b_packb() has a bug if error_class > 3 */
        b_packb( (unsigned char)( (unsigned char)cause_code.error_class & 0x3),
                 data,
                 (unsigned short) (pos * 8 + 6),
                 2 );  /* low 2 bits */
        
        pos++; /* skip first parm data byte */
        
        if( cause_code.error_class != WMS_ERROR_NONE )
        {
          data[pos] = (unsigned char) (cause_code.tl_status);
          pos++; /* skip second parm data byte */
        }
        #endif

        ALOGD("simcom_cdma_encode_sms beaeer data pos %d, uBearerDataLen %d", pos, msg->uBearerDataLen);    
      
        data[pos] = (unsigned char) WMS_TL_BEARER_DATA;
        pos++; /* skip parm id */
  
        data[pos] = (unsigned char) MIN (msg->uBearerDataLen, RIL_CDMA_SMS_BEARER_DATA_MAX);
        pos++; /* skip parm len */

        len = MIN((unsigned char)msg->uBearerDataLen, (unsigned char)RIL_CDMA_SMS_BEARER_DATA_MAX-pos);
        memcpy( (unsigned char *)data+pos, msg->aBearerData, len);

        pos += (unsigned short)len; /* skip parm data */

        ALOGD("simcom_cdma_encode_sms enc over pos %d", pos);    

        if( st != WMS_OK_S)
        {
            // encoded data has too many bytes
            ALOGE( "Invalid parm size: %d", pos);
            goto Error;
        }

        if(simcom_sms_convert_bin_to_hex(data, encoded_sms->data, pos) < 0)
        {
            ALOGE( "simcom_cdma_encode_sms convert to hex failed!");
            goto Error;
        }
        encoded_sms->length = 2 * pos;
    }

    ret = RIL_E_SUCCESS;
  
Error:

    return ret;
}

#endif /* SIMCOM_RADIO_CDMA */

