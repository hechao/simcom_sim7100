/*============================================================================
   DESCRIPTION
       This file implements the RIL requests from application., It replaces the 
  original functions.

 Copyright (c) 2011 by simcom, Incorporated.  All Rights Reserved.
============================================================================*/

/*============================================================================

                      EDIT HISTORY FOR FILE

 This section contains comments describing changes made to this file.
 Notice that changes are listed in reverse chronological order.

 Header: hardware/ril/reference-ril/reference-ril-simcom.h

 when            who            what, where, why     
 --------     ----  ----------------------------------------------------------
 
11/05/04     aaron        initial version
============================================================================*/

#ifdef SIMCOM_RADIO

/*============================================================================
                        INCLUDE 
============================================================================*/
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include "reference-ril-simcom.h"
#include "../../../system/core/include/cutils/properties.h"

#ifdef SIMCOM_RADIO_NDIS

#include <sys/socket.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <dirent.h>
#include <netinet/in.h>
#include <net/if.h>
#include <net/route.h>
#include "GobiNetworkManager.h"


#define NDIS_DEVICE_NAME_PREFIX "qcqmi"

char g_ndis_device_name[32];
char g_ndis_tty_name[IFNAMSIZ] = { 0 };

static int g_data_service_need_resume = 0;

static struct sGobiNMParam g_ds_gobiNMParam;

#endif /* SIMCOM_RADIO_NDIS */

/*============================================================================
                        MACRO
============================================================================*/

#define LOG_TAG "RIL_SIMCOM"
#include <utils/Log.h>

#define PPP_TTY_PATH "ppp0"
#define PPPD_SERVICE_NAME    "pppd_gprs"
#define PPPD_EXIT_CODE           "net.gprs.ppp-exit"
#define PPP_NET_LOCAL_IP        "net.ppp0.local-ip"
#define PPP_OPERSTATE_PATH "/sys/class/net/ppp0/operstate"

#ifdef SIMCOM_RADIO_CDMA
#define PPP_TYPE_NAME     "IP"
#endif

#define POLL_PPP_SYSFS_SECONDS	5
#define POLL_PPP_SYSFS_RETRY	5

/*============================================================================
                        VARIABLE
============================================================================*/
/*
  * status about the process pppd
  */
 static int pppd_started = 0;

typedef struct _s_listmap {
    char *str;
    int flag;
}s_listmap;

static const s_listmap g_call_cause[] =
{
    /* cause codes defined in TS 24.008 Annex H */
    {"ACM >= ACMmax",       68},
    {"Access information discarded",        43},
    {"Bearer capability not authorized",    57},
    {"Bearer capability not available",     58},
    {"Bearer service not implemented",      65},
    {"Call rejected",       21},
    {"Channel unacceptable",        6},
    {"Client ended call", 128},
    {"Conditional IE error",        100},
    {"Destination out of order",    27},
    {"Facility rejected",   29},
    {"IE non-existent/not implemented",     99},
    {"Incoming calls barred within the CUG",        55},
    {"Incompatible destination",    88},
    {"Interworking, unspecified",   127},
    {"Invalid mandatory information",       96},
    {"Invalid transaction identifier value",        81},
    {"Invalid transit network selection",   91},
    {"Invalid/incomplete number",   28},
    {"Message non-existent/not implemented",        97},
    {"Message not compatible with state",   101},
    {"Message type not compatible with state",      98},
    {"Network out of order",        38},
    {"No cause information available", 16},
    {"No circuit/channel available",        34},
    {"No route to destination",     3},
    {"No user responding",  18},
    {"Non selected user clearing",  26},
    {"Normal call clearing",        16},
    {"Normal, unspecified", 31},
    {"Number changed",      22},
    {"Only RDI bearer is available",        70},
    {"Operator determined barring", 8},
    {"Other cause", 129},
    {"pre-emption", 25},        /* add */
    {"Protocol error, unspecified", 111},
    {"Quality of service unavailable",      49},
    {"Recovery on timer expiry",    102},
    {"Requested circuit/channel not available",     44},
    {"Requested facility not implemented",  69},
    {"Requested facility not subscribed",   50},
    {"Resources unavailable, unspecified",  47},
    {"Response to Status Enquiry",  30},
    {"Semantically incorrect message",      95},
    {"Service/option not available",        63},
    {"Service/option not implemented",      79},
    {"Switching equipment congestion",      42},
    {"Temporary failure",   41},
    {"Unassigned/unalloacted number",       1},
    {"User alerting, no answer",    19},
    {"User busy",   17},
    {"User not member of CUG",      87}
};

extern const char * requestToString(int request);

/*============================================================================
                        FUNCTION DEFINITION
============================================================================*/
/*
  * This function is used to match substring in string anythere
  */
int at_tok_matchstring(char **p_cur, char *p_match)
{
    char *ret;

    if (*p_cur == NULL) {
        return -1;
    }

    /* skip space */
    while (**p_cur != '\0' && isspace(**p_cur)) {
        (*p_cur)++;
    }

    if (*p_cur == NULL) {
        ret = NULL;
    } else {
        ret = strsep(p_cur, p_match);
    }

    if (ret == NULL) {
        return -1;
    } 

    return 0;
}

/*
  * This function is used to match substring in string beginning
  */
int at_tok_matchstringbeginning(char **p_cur, char *p_match)
{
    char *ret;

    if (*p_cur == NULL) {
        return -1;
    }

    /* skip space */
    while (**p_cur != '\0' && isspace(**p_cur)) {
        (*p_cur)++;
    }

    if (*p_cur == NULL) {
        ret = NULL;
    } else {
        ret = strstr(*p_cur, p_match);
        if(ret != *p_cur) {
            ret = NULL;
        }
        else {
            (*p_cur)++;
        }
    }

    if (ret == NULL) {
        return -1;
    } 

    return 0;
}

/*
  * This function is used to comparison routine used for binary search below
  */
static int listmap_compare_strings(const void* p_elem1, const void* p_elem2)
{
    char *s1 = ((s_listmap *)p_elem1)->str;
    char *s2 = ((s_listmap *)p_elem2)->str;
    return strcmp(s1, s2);
}

/*
  * This function is used to find correspondig flag to the string
  */
int listmap_flag_from_string(const char *str, const s_listmap* const listmap_array, const int listmap_array_len, int *flag)
{
    s_listmap mapkey;
    s_listmap* p_mapfound;

    if(!str || !listmap_array || !flag)
        return -1;

    /* Add correspondig flag to the mask */
    mapkey.str = (char *)str;
    p_mapfound = (s_listmap*)bsearch((const void *)&mapkey, (const void *)listmap_array, 
        listmap_array_len, 
        sizeof(listmap_array[0]), 
        listmap_compare_strings);
    if(p_mapfound == NULL)
    {
        *flag=0;
        return -1;
    }
    
    *flag = p_mapfound->flag;
    return 0;    
}
/*
  * This function is used to get the returned int value
  * from the AT response string.
  * example:
  * AT+CFUN?   ->
  * +CFUN: 1 <-
  * This function will return the value "1" of this example.
  */
static int get_int_val_from_at_resp(char *at_resp, int index)
{
    int err;
    int ret; 

    err = at_tok_start(&at_resp);
    if (err < 0) goto error;

   while(index >= 0)
    {
    	err = at_tok_nextint(&at_resp, &ret);
   	 if (err < 0) goto error;

	 index--;
   }
   
    return (int)ret;

error:

    return -1;
}

/*
  * This function is used to get the returned string value
  * from the AT response string.
  * example:
  * AT+CGMR -> 
  * +CGMR: SIM5320_V1.5
  * This function will return the pointer which pointe to "SIM5320_V1.5"
  */
static char *get_str_val_from_at_resp(char *at_resp)
{
    int err;
    char *ret_str = at_resp; 

    err = at_tok_start(&ret_str);
    if (err < 0) goto error;

    return ret_str;

error:
    return NULL;
}

/*===========================================================================

FUNCTION simcom_request_checkdevice

DESCRIPTION
  [REPLACE-ADD] please refer at command set, 
  
PARAMETERS
  None.

DEPENDENCIES
  None.

RETURN VALUE
  [bool] true indicate device not ready, false indicate device ready
  
SIDE EFFECTS
  None.

===========================================================================*/
int  simcom_check_device_ready()
{
    int err;
    ATResponse *p_response = NULL;
    char *response = 0;
    char *line;
    int ret = -1;

    err = at_send_command_singleline("AT+CGMI", "", &p_response);

    if (err < 0 || p_response->success == 0) {
        goto error;
    }

    line = p_response->p_intermediates->line;
    err = at_tok_nextstr(&line, &response);
    if (err < 0) {
        goto error;
    }

    if(strcmp(response, "SIMCOM INCORPORATED") == 0) {
        ret = 1;
    }
    else {
        goto error;
    }

    at_response_free(p_response);
    return ret;
    
error:
    at_response_free(p_response);
    LOGE("simcom_check_device_ready must never return error when radio is on\n");
    return -1;
}

/*===========================================================================

FUNCTION simcom_request_checkdevice

DESCRIPTION
  [REPLACE-ADD] please refer at command set, 
  
PARAMETERS
  None.

DEPENDENCIES
  None.

RETURN VALUE
  [bool] true indicate device not ready, false indicate device ready
  
SIDE EFFECTS
  None.

===========================================================================*/
int  simcom_check_simcard_ready()
{
    int err;
    ATResponse *p_response = NULL;
    char *response = 0;
    char *line;
 
    err = at_send_command_singleline("AT+CICCID", "+ICCID:", &p_response);

    if (err < 0 || p_response->success == 0) {
        goto error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);

    if (err < 0) {
        goto error;
    }

    err = at_tok_nextstr(&line, &response);
    if (err < 0) {
        goto error;
    }

    at_response_free(p_response);
    return 0;
    
error:
    at_response_free(p_response);
    LOGE("simcom_check_simcard_ready must never return error when radio is on\n");
    return -1;
}

/*===========================================================================

FUNCTION requestSendSMS

DESCRIPTION
  [REPLACE] please refer the command RIL_REQUEST_SEND_SMS 

PARAMETERS
    [in] data  -
    [in] datalen -
    [in] t - 
       

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
 void simcom_request_sendSMS(void *data, size_t datalen, RIL_Token t)
{
    int err;
    const char *smsc;
    const char *pdu;
    int tpLayerLength;
    char *cmd = NULL;
    char *pdu_ctx = NULL;
    RIL_SMS_Response response;
    ATResponse *p_response = NULL;

    smsc = ((const char **)data)[0];
    pdu = ((const char **)data)[1];

    tpLayerLength = strlen(pdu)/2;

    // "NULL for default SMSC"
    if (smsc == NULL) {
        smsc= "00";
    }

    /*just use +CMGSO to send sms*/
    asprintf(&pdu_ctx, "\"%s%s\"", smsc, pdu);
    asprintf(&cmd, "AT+CMGSO=%d,%s", tpLayerLength, pdu_ctx);

    err = at_send_command_singleline(cmd, "+CMGSO:", &p_response);

    if (err != 0 || p_response->success == 0) goto error;

    memset(&response, 0, sizeof(response));

    RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, sizeof(response));
    at_response_free(p_response);
    free(cmd);
    free(pdu_ctx);

    return;
error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
    free(cmd);
    free(pdu_ctx);
}

/*===========================================================================

FUNCTION simcom_request_test_at

DESCRIPTION
  [ADD] This function is used to send AT command to the module
  
PARAMETERS

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_test_at(void *data, size_t datalen, RIL_Token t)
{
    char *cmd = NULL;
	asprintf(&cmd, "%s",  (const char *)data);

	//LOGD("OnRequest, before RIL_SIMCOM_TEST_AT :%s", cmd);

	at_send_command(cmd, NULL);

	free(cmd);
	
        RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

/*===========================================================================

FUNCTION simcom_request_set_mute

DESCRIPTION
  [REPLACE-ADD] please refer the command RIL_REQUEST_SET_MUTE 
  
PARAMETERS
	[in] data - 
		

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_set_mute(void *data, size_t datalen, RIL_Token t)
{
 	 ATResponse *p_response = NULL;
	int err;
    char *cmd = NULL;
	asprintf(&cmd, "AT+CMUT=%d", ((int *)data)[0]);

	//LOGD("OnRequest, before RIL_REQUEST_SET_MUTE :%s", cmd);

	err = at_send_command(cmd,  &p_response);
	free(cmd);
	
     if (err < 0 || p_response->success == 0) {
          RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
      } else {
          RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
      }
      at_response_free(p_response);
}

/*===========================================================================

FUNCTION simcom_request_set_mute

DESCRIPTION
  [REPLACE-ADD] please refer the command RIL_REQUEST_QUERY_FACILITY_LOCK 
  
PARAMETERS
	[in] data - 
		

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_query_facility_lock(void *data, size_t datalen, RIL_Token t)
{
	/*+CLCK*/
        ATResponse *p_response;
        int err;

	int ret_val = 0;
    char *cmd = NULL;
	asprintf(&cmd, "AT+CLCK=\"%s\",2,\"%s\",%d", ((const char **)data)[0], ((const char **)data)[1], atoi(((const char **)data)[2]));

	//LOGD("OnRequest, before RIL_REQUEST_QUERY_FACILITY_LOCK :%s", cmd);
		 
 	err = at_send_command_singleline(cmd, "+CLCK:", &p_response);
         free(cmd);
		 
     if (err < 0 || p_response->success == 0) {
          RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
      } else {
          ret_val = get_int_val_from_at_resp(p_response->p_intermediates->line, 0);
          RIL_onRequestComplete(t, RIL_E_SUCCESS, &ret_val, sizeof(ret_val));
      }
      at_response_free(p_response);
}

/*===========================================================================

FUNCTION simcom_request_screen_state

DESCRIPTION
  [REPLACE-ADD] please refer the command RIL_REQUEST_SCREEN_STATE 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_screen_state(void *data, size_t datalen, RIL_Token t)
{
	/*
	  * Currently the request is implemented like this:
	  * 1. Signal strength is not reported while SCREEN is off.
	  * 2. Only different signal strength is reported while SCREEN is on.
	  * 
	  * just use +AUTOCSQ.
	  */
        ATResponse *p_response;
        int err;

        //LOGD("OnRequest, before RIL_REQUEST_SCREEN_STATE ");

      if(((int *)data)[0] == 1)
	  	err = at_send_command("AT+AUTOCSQ=1,1",  &p_response);
      else if(((int *)data)[0] == 0)
	  	err = at_send_command("AT+AUTOCSQ=0",  &p_response);
      else
      {
      		RIL_onRequestComplete(t, RIL_E_REQUEST_NOT_SUPPORTED, NULL, 0);
		return;
      }
	  		 
     if (err < 0 || p_response->success == 0) {
          RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
      } else {
          RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
      }
      at_response_free(p_response);
}

/*===========================================================================

FUNCTION simcom_request_baseband_version

DESCRIPTION
  [REPLACE-ADD] please refer the command RIL_REQUEST_BASEBAND_VERSION 
  
PARAMETERS
	[in] data - 
		

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_baseband_version(RIL_Token t)
{
	/*+CGMR*/
	ATResponse *p_response;
        int err;

	char *ret_str = NULL;
	//LOGD("OnRequest, before RIL_REQUEST_BASEBAND_VERSION");

	err = at_send_command_singleline ("AT+CGMR", "+CGMR:", &p_response);

     if (err < 0 || p_response->success == 0) {
          RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
      } else {
          ret_str = get_str_val_from_at_resp(p_response->p_intermediates->line);
		
	    if(ret_str != NULL)		
          	RIL_onRequestComplete(t, RIL_E_SUCCESS, ret_str, strlen(ret_str));
	    else
		RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
      }
      at_response_free(p_response);
}

/*===========================================================================

FUNCTION simcom_request_usb_audio

DESCRIPTION
  [ADD] This function is used to enable/disable usb audio
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_usb_audio(void *data, size_t datalen, RIL_Token t)
{
    int err;
    ATResponse *p_response;	
	
    char  cmd[20];
    //LOGD("OnRequest, before switch to USB AUDIO");

    sprintf(cmd, "AT+DSWITCH=%d", ((int *)data)[0]);

 /* user determined user busy */
     /* sometimes used: ATH */
     err = at_send_command(cmd, &p_response);
 
     if (err < 0 || p_response->success == 0) {
            RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
	   return;
      }
      at_response_free(p_response);

    sprintf(cmd, "AT+CPCMREG=%d", ((int *)data)[0]);

     err = at_send_command(cmd, &p_response);

     if (err < 0 || p_response->success == 0) {
          RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
      } else {
          	RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
      }
      at_response_free(p_response);
}

/*===========================================================================

FUNCTION simcom_request_set_facility_lock

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_SET_FACILITY_LOCK 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_set_facility_lock(void *data, size_t datalen, RIL_Token t)
{
	ATResponse *p_response;
        int err;
    char *cmd = NULL;

	asprintf(&cmd, "AT+CLCK=\"%s\",%d,\"%s\",%d", ((const char **)data)[0],
						      atoi(((const char **)data)[1]),
						      ((const char **)data)[2],
						      atoi(((const char **)data)[3]));

	//LOGD("OnRequest, before RIL_REQUEST_SET_FACILITY_LOCK :%s", cmd);

	err = at_send_command(cmd, &p_response);
	
 	free(cmd);

        if (err < 0 || p_response->success == 0) {
          RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        } else {
         	RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
        }
      at_response_free(p_response);	
}

/*===========================================================================

FUNCTION simcom_request_change_sim_pin

DESCRIPTION
    [REPLACE] please refer the command RIL_REQUEST_CHANGE_SIM_PIN and 
		RIL_REQUEST_CHANGE_SIM_PIN2 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_change_sim_pin(int request, void *data, size_t datalen, RIL_Token t)
{
	ATResponse *p_response;
        int err;
    char *cmd = NULL;

	if(request == RIL_REQUEST_CHANGE_SIM_PIN)
		asprintf(&cmd, "AT+CPWD=\"SC\",%s,%s", ((const char **)data)[0],
						        ((const char **)data)[1]);
	else if(request == RIL_REQUEST_CHANGE_SIM_PIN2)
		asprintf(&cmd, "AT+CPWD=\"P2\",%s,%s", ((const char **)data)[0],
						        ((const char **)data)[1]);
	else
	{
		RIL_onRequestComplete(t, RIL_E_REQUEST_NOT_SUPPORTED, NULL, 0);
		return;
	}

	//LOGD("OnRequest, before %s :%s", requestToString(request), cmd);

	err = at_send_command(cmd, &p_response);
	
 	free(cmd);

        if (err < 0 || p_response->success == 0) {
          RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        } else {
         	RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
        }
        at_response_free(p_response);
}

/*===========================================================================

FUNCTION simcom_request_change_sim_pin

DESCRIPTION
    [REPLACE] please refer the command RIL_REQUEST_ENTER_SIM_PIN, 
				      RIL_REQUEST_ENTER_SIM_PUK,
				      RIL_REQUEST_ENTER_SIM_PIN2,
				      RIL_REQUEST_ENTER_SIM_PUK2
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_enter_sim_pin(int request, void *data, size_t datalen, RIL_Token t)
{
	ATResponse *p_response;
        int err;
    char *cmd = NULL;
	int try_cnt = 3;

	if(request == RIL_REQUEST_ENTER_SIM_PIN ||
	   request == RIL_REQUEST_ENTER_SIM_PIN2)
		asprintf(&cmd, "AT+CPIN=%s", ((const char **)data)[0]);
	else if(request == RIL_REQUEST_ENTER_SIM_PUK ||
		 request == RIL_REQUEST_ENTER_SIM_PUK2)
		asprintf(&cmd, "AT+CPIN=%s,%s", ((const char **)data)[0],((const char **)data)[1]);
	else
	{
		RIL_onRequestComplete(t, RIL_E_REQUEST_NOT_SUPPORTED, NULL, 0);
		return;
	}

	//LOGD("OnRequest, before %s :%s", requestToString(request), cmd);

	err = at_send_command(cmd, &p_response);
	
 	free(cmd);

        if (err < 0 || p_response->success == 0) {

	err = at_send_command_singleline("AT+SPIC",  "+SPIC:", &p_response);   /*get the try counts*/

          if (err < 0 || p_response->success == 0) 
		  	try_cnt = -1;
	else
	{
		if(request == RIL_REQUEST_ENTER_SIM_PIN)
			try_cnt = get_int_val_from_at_resp(p_response->p_intermediates->line, 0);
		else   if(request == RIL_REQUEST_ENTER_SIM_PIN2)
			try_cnt = get_int_val_from_at_resp(p_response->p_intermediates->line, 2);
		else   if(request == RIL_REQUEST_ENTER_SIM_PUK)
			try_cnt = get_int_val_from_at_resp(p_response->p_intermediates->line, 1);
		else   if(request == RIL_REQUEST_ENTER_SIM_PUK2)
			try_cnt = get_int_val_from_at_resp(p_response->p_intermediates->line, 3);
		else 
			try_cnt = -1;
	}

	RIL_onRequestComplete(t, RIL_E_PASSWORD_INCORRECT, &try_cnt, sizeof(try_cnt));

        } else {
		try_cnt = 3;
		RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, &try_cnt, sizeof(try_cnt));
        }
      at_response_free(p_response);
}

/*===========================================================================

FUNCTION simcom_request_stk_service_is_running

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_REPORT_STK_SERVICE_IS_RUNNING, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_stk_service_is_running(RIL_Token t)
{
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL,0);
}

#ifdef SIMCOM_RADIO_CDMA
void requestOrSendDataCallList_cdma(RIL_Token *t, const char *ip_str)
{
    RIL_Data_Call_Response_v6 *responses =
        alloca(1 * sizeof(RIL_Data_Call_Response_v6));

        responses->status = 0;
        responses->suggestedRetryTime = -1;
        responses->cid = 1;
        responses->active = 2;

        responses->type = alloca(strlen(PPP_TYPE_NAME) + 1);
        strcpy(responses->type, PPP_TYPE_NAME);

        responses->ifname = alloca(strlen(PPP_TTY_PATH) + 1);
        strcpy(responses->ifname, PPP_TTY_PATH);

        responses->addresses = alloca(strlen(ip_str) + 1);
        strcpy(responses->addresses, ip_str);

        responses->dnses = "";
        responses->gateways = "";

    if (t != NULL)
        RIL_onRequestComplete(*t, RIL_E_SUCCESS, responses,
                              1 * sizeof(RIL_Data_Call_Response_v6));
    else
        RIL_onUnsolicitedResponse(RIL_UNSOL_DATA_CALL_LIST_CHANGED,
                                  responses,
                                  1 * sizeof(RIL_Data_Call_Response_v6));
}
#endif

extern void requestOrSendDataCallList(RIL_Token *t);
 /*===========================================================================

FUNCTION simcom_request_setup_datacall

DESCRIPTION
    [REPLACE] please refer the command RIL_REQUEST_SETUP_DATA_CALL, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
 void simcom_request_setup_datacall(void *data, size_t datalen, RIL_Token t)
{
    const char *apn;
    char *cmd = NULL;
    int err;
    ATResponse *p_response = NULL;
    char *response[2] = { "1", PPP_TTY_PATH };
   // RIL_Data_Call_Response_v6 response;
    int fd;
    char buffer[20];
    char exit_code[PROPERTY_VALUE_MAX];
    static char local_ip[PROPERTY_VALUE_MAX];
    int retry = POLL_PPP_SYSFS_RETRY;

    apn = ((const char **)data)[2];

    LOGD("requesting data connection to APN '%s'", apn);

    if(pppd_started) {
	// clean up any existing PPP connection before activating new PDP context
	LOGD("Stop existing PPPd before activating PDP");
	property_set("ctl.stop", PPPD_SERVICE_NAME);
	pppd_started = 0;
    }

#ifndef SIMCOM_RADIO_CDMA
   err = at_send_command("at$qcpdplt=0",  &p_response);
   at_response_free(p_response);

   asprintf(&cmd, "AT+CGDCONT=1,\"IP\",\"%s\",,0,0", apn);
    err = at_send_command(cmd,  &p_response);
    free(cmd);

    if (err < 0 || p_response->success == 0) {
        goto error;
    }
	at_response_free(p_response);
#endif

    // Setup PPP connection after PDP Context activated successfully
    // The ppp service name is specified in /init.rc
    property_set(PPPD_EXIT_CODE, "");
    property_set(PPP_NET_LOCAL_IP, "");
    err = property_set("ctl.start", PPPD_SERVICE_NAME);
    pppd_started = 1;
    if (err < 0) {
	LOGW("Can not start PPPd");
	goto ppp_error;
    }
    LOGD("PPPd started");

   /**
    * FIX ME!!!
    * following code should be debuged more time.
    */ 
#if 1
    // Wait for PPP interface ready
    sleep(2);
    do {
	// Check whether PPPD exit abnormally
	property_get(PPPD_EXIT_CODE, exit_code, "");
	if(strcmp(exit_code, "") != 0) {
	    LOGW("PPPd exit with code %s", exit_code);
	    retry = 0;
	    break;
        }

        fd  = open(PPP_OPERSTATE_PATH, O_RDONLY);
        if (fd >= 0)  {
	    buffer[0] = 0;
            read(fd, buffer, sizeof(buffer));
	    close(fd);
	    if(!strncmp(buffer, "up", strlen("up")) || !strncmp(buffer, "unknown", strlen("unknown"))) {
		// Should already get local IP address from PPP link after IPCP negotation 
		// system property net.ppp0.local-ip is created by PPPD in "ip-up" script 
		#if 1
                local_ip[0] = 0;
		property_get(PPP_NET_LOCAL_IP, local_ip, "");
		if(!strcmp(local_ip, "")) {
		    LOGW("PPP link is up but no local IP is assigned. Will retry %d times after %d seconds", \
			  retry-1, POLL_PPP_SYSFS_SECONDS);
			#ifndef SIMCOM_RADIO_CDMA
			if (retry == 1)
				{
				    LOGW("PPP link is up but no local IP is assigned. Try get IP from modem!");
					err = at_send_command_singleline("AT+CGPADDR=1", "+CGPADDR:", &p_response);
					if (err < 0 || p_response->success == 0)
						goto error;
					
					char* line = p_response->p_intermediates->line;
					int cid = -1;
					char* ipaddr;
					err = at_tok_start(&line);
					err = at_tok_nextint(&line, &cid);
					if (cid != 1) {
						LOGW("cid not equal 1, something error may be happened");
						goto error;
					}
					err = at_tok_nextstr(&line, &ipaddr);
					if (ipaddr != NULL)
						{
							strcpy(local_ip, ipaddr);
							LOGW("Get IP %s from modem", local_ip);
						}
					at_response_free(p_response);
					break;
				}
			#endif
		} else {
		    LOGD("PPP link is up with local IP address %s", local_ip);
		    // other info like dns will be passed to framework via property (set in ip-up script)
		 //   response[2] = local_ip; 
    		   // response.addresses = local_ip;
		    // now we think PPPd is ready
		    break;	
		}
		#endif 
	    } else {
		LOGW("PPP link status in %s is %s. Will retry %d times after %d seconds", \
		    PPP_OPERSTATE_PATH, buffer, retry, POLL_PPP_SYSFS_SECONDS);
	    }
	} else {
    	    LOGW("Can not detect PPP state in %s. Will retry %d times after %d seconds", \
		  PPP_OPERSTATE_PATH, retry-1, POLL_PPP_SYSFS_SECONDS);
	}
        sleep(POLL_PPP_SYSFS_SECONDS);
    } while (--retry);

    if(retry == 0)
	goto ppp_error;

#endif

   // RIL_onRequestComplete(t, RIL_E_SUCCESS, response, sizeof(response));
#ifndef SIMCOM_RADIO_CDMA
    requestOrSendDataCallList(&t);
#else
   requestOrSendDataCallList_cdma(&t, local_ip);
#endif

    return;
ppp_error:
#ifndef SIMCOM_RADIO_CDMA
   /* PDP activated successfully, but PPP connection can't be setup. So deactivate PDP context */
    at_send_command("AT+CGACT=0,1", NULL);
#endif
    /* If PPPd is already launched, stop it */
    if(pppd_started) {
	property_set("ctl.stop", PPPD_SERVICE_NAME);
	pppd_started = 0;
    }
    // fall through

error:
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);

}

 /*===========================================================================

FUNCTION simcom_request_deactive_data_call

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_DEACTIVATE_DATA_CALL, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_deactive_data_call(void *data, size_t datalen, RIL_Token t)
{
    const char *cid;
    char *cmd = NULL;
    int err;

    cid = ((const char **)data)[0];
    LOGD("requesting deactivating data connection with CID '%s'", cid);

    /* Stop PPPd firstly */
    LOGD("Stopping PPPD");

    if(pppd_started)
    	  property_set("ctl.stop", PPPD_SERVICE_NAME);

    pppd_started = 0;

#if 0
    /* Dactivate PDP Context */
    asprintf(&cmd, "AT+CGACT=0,%d", atoi(cid));
    err = at_send_command(cmd, NULL);

    if (err < 0 ) {
	LOGW("Dactivate PDP failure");
    }
#endif

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    free(cmd);

    return;
}

#ifdef SIMCOM_RADIO_NDIS
 /*===========================================================================

FUNCTION simcom_request_setup_datacall_ndis

DESCRIPTION
    [REPLACE] please refer the command RIL_REQUEST_SETUP_DATA_CALL,

PARAMETERS
	[in] data -

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
 void simcom_request_setup_datacall_ndis(void *data, size_t datalen, RIL_Token t)
{
    const char *apn, *username, *passwd, *ip_type, *auth_type, *profile;
    char *cmd = NULL;
    int err;
    ATResponse *p_response = NULL;
    RIL_Data_Call_Response_v6 responses;
    int fd;
    char buffer[20];
    char exit_code[PROPERTY_VALUE_MAX];
    DIR  *dev_dir;
    struct dirent *dir_entry;
    struct sGobiNMParam *p_gobiNMParam, mms_gobiNMParam;

    profile = ((const char **)data)[1];
    apn = ((const char **)data)[2];
    username = ((const char **)data)[3];
    passwd = ((const char **)data)[4];
    auth_type = ((const char **)data)[5];
    ip_type = ((const char **)data)[6];

    LOGD("requesting data connection profile '%s'", profile);
    LOGD("requesting data connection to APN '%s'", apn);
    LOGD("requesting data connection to username '%s'", username);
    LOGD("requesting data connection to passwd '%s'", passwd);
    LOGD("requesting data connection to auth_type '%s'", auth_type);
    LOGD("requesting data connection to ip_type '%s'", ip_type);

    dev_dir = opendir("/dev");

    if (dev_dir == NULL)
    {
        LOGE("Fail to open dir /dev, error: %s\n", strerror(errno));
        goto error;
    }

    while (dir_entry = readdir(dev_dir))
    {
        if (strstr(dir_entry->d_name, NDIS_DEVICE_NAME_PREFIX) && dir_entry->d_type == DT_CHR)
        {
            LOGD("find NDIS Device File: %s\n", dir_entry->d_name);
            sprintf(g_ndis_device_name, "/dev/%s", dir_entry->d_name);
            break;
        }
    }

    closedir(dev_dir);

    if (strstr(g_ndis_device_name, NDIS_DEVICE_NAME_PREFIX) == 0)
    {
        LOGE("Can not find NDIS Device file: /dev/%s*\n", NDIS_DEVICE_NAME_PREFIX);
        goto error;
    }

    fd = open(g_ndis_device_name, O_RDWR);
    if (fd < 0)
    {
        LOGD("fail to open device ''%s', err: %d", g_ndis_device_name, fd);
        goto error;
    }

    err = ioctl(fd, IOCTL_QMI_GET_NETWORK_STATUS, 0);

    if (err == NM_STATE_CONNECTED)
    {
        err = ioctl(fd, IOCTL_QMI_STOP_NETWORK, 0);
        if (err == 0)
        {
            LOGD("before start mms network, success to stop data network");

            responses.status = PDP_FAIL_ERROR_UNSPECIFIED;
            responses.suggestedRetryTime = -1;
            responses.cid = 0;
            responses.active = 0;
            responses.type = "";
            responses.ifname = "";
            responses.addresses = "";
            responses.dnses = "";
            responses.gateways = "";

            RIL_onUnsolicitedResponse(RIL_UNSOL_DATA_CALL_LIST_CHANGED,
                                  responses,
                                  1 * sizeof(RIL_Data_Call_Response_v6));
            g_data_service_need_resume = 1;

            p_gobiNMParam = &mms_gobiNMParam;
        }
        else
        {
            LOGD("before start mms network, fail to stop data network, errno: %d", err);
            goto error;
        }
    }
    else
    {
        p_gobiNMParam = &g_ds_gobiNMParam;
    }

    memset(p_gobiNMParam, 0, sizeof(struct sGobiNMParam));

    if (username)
    {
        memcpy(p_gobiNMParam->username, username, strlen(username));
    }

    if (passwd)
    {
        memcpy(p_gobiNMParam->passwd, passwd, strlen(passwd));
    }

	if (apn)
    {
        memcpy(p_gobiNMParam->apn, apn, strlen(apn));
    }

    if (auth_type)
    {
        p_gobiNMParam->auth_type = atoi(auth_type);
    }
    else
    {
        p_gobiNMParam->auth_type = AUTH_PROTOCOL_UNSPECIFIED;
    }

    if (ip_type)
    {
        if (strcmp(ip_type, "IPV4") == 0)
        {
            p_gobiNMParam->ip_type = IP_TYPE_IPV4;
        }
        else if (strcmp(ip_type, "IPV6") == 0)
        {
            p_gobiNMParam->ip_type = IP_TYPE_IPV6;
        }
        else
        {
            p_gobiNMParam->ip_type = IP_TYPE_UNSPECIFIED;
        }
    }
    else
    {
        p_gobiNMParam->ip_type = IP_TYPE_UNSPECIFIED;
    }

    err = ioctl(fd, IOCTL_QMI_START_NETWORK, p_gobiNMParam);

    if (err == 0)
    {
        char cmd[64];

        LOGD("success to start network interface\n");

        if (0 != (err = ioctl(fd, IOCTL_QMI_GET_NET_INTERFACE_NAME, g_ndis_tty_name)))
        {
            LOGD("fail to get net interface name %s, err: %d\n", g_ndis_tty_name, err);
            close(fd);
            goto error;
        }
        LOGD("success to get net interface name: %s", g_ndis_tty_name);
        snprintf(cmd, 64, "netcfg %s dhcp", g_ndis_tty_name);
        system(cmd);
        LOGD("Execute CMD '%s'\n", cmd);
    }
    else if (err == -1)
    {
        ALOGD("can't restart network interface'\n");
    }
    else
    {
        LOGD("fail to start network interface, error: %d\n", err);
        close(fd);
        goto error;
    }
    close(fd);
    requestOrSendDataCallList(&t);
    return;

error:

    responses.status = PDP_FAIL_ERROR_UNSPECIFIED;
    responses.suggestedRetryTime = -1;
    responses.cid = 0;
    responses.active = 0;
    responses.type = "";
    responses.ifname = "";
    responses.addresses = "";
    responses.dnses = "";
    responses.gateways = "";

    RIL_onRequestComplete(t, RIL_E_SUCCESS, &responses, sizeof(RIL_Data_Call_Response_v6));
    at_response_free(p_response);
}

 /*===========================================================================

FUNCTION simcom_request_deactive_data_call_ndis

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_DEACTIVATE_DATA_CALL, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_deactive_data_call_ndis(void *data, size_t datalen, RIL_Token t)
{
    int fd, err;
    struct sGobiNMParam *p_gobiNMParam;

    if (strstr(g_ndis_device_name, NDIS_DEVICE_NAME_PREFIX))
    {
        fd = open(g_ndis_device_name, O_RDWR);
    }
    else
    {
        LOGE("NDIS File [%s] is not valid", g_ndis_device_name);
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        return;
    }
    if (fd < 0)
    {
        LOGD("fail to open device ''%s', err: %d", g_ndis_device_name, fd);
        RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
        return;
    }

    err = ioctl(fd, IOCTL_QMI_STOP_NETWORK, 0);

    if (err == 0)
    {
        LOGD("success to stop network interface\n");
        RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    }
    else
    {
        LOGD("fail to stop network interface, error: %d\n", err);
        goto error;
    }

    if (g_data_service_need_resume)
    {
        p_gobiNMParam = &g_ds_gobiNMParam;
        LOGD("resume data connection APN '%s'", p_gobiNMParam->apn);
        LOGD("resume data connection username '%s'", p_gobiNMParam->username);
        LOGD("resume data connection passwd '%s'", p_gobiNMParam->passwd);
        LOGD("resume data connection auth_type '%d'", p_gobiNMParam->auth_type);
        LOGD("resume data connection ip_type '%d'", p_gobiNMParam->ip_type);

        err = ioctl(fd, IOCTL_QMI_START_NETWORK, p_gobiNMParam);

        if (err == 0)
        {
            char cmd[64];

            ALOGD("success to resume data network interface\n");

            if (0 != (err = ioctl(fd, IOCTL_QMI_GET_NET_INTERFACE_NAME, g_ndis_tty_name)))
            {
                ALOGD("fail to get net interface name %s, err: %d\n", g_ndis_tty_name, err);
                ioctl(fd, IOCTL_QMI_STOP_NETWORK, 0);
                goto error;
            }
            else
            {
                ALOGD("success to get net interface name: %s", g_ndis_tty_name);
                snprintf(cmd, 64, "netcfg %s dhcp", g_ndis_tty_name);
                system(cmd);
                ALOGD("Execute CMD '%s'\n", cmd);
            }
        }
        else if (err == -1)
        {
            ALOGD("can't restart network interface'\n");
        }
        else
        {
            ALOGD("fail to start network interface, error: %d\n", err);
            goto error;
        }
    }

    close(fd);
    requestOrSendDataCallList(NULL);
    return;

 error:
    close(fd);

    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);

    return;
}

#endif /* SIMCOM_RADIO_NDIS */

/*===========================================================================

FUNCTION simcom_request_get_clir

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_GET_CLIR, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_get_clir(void *data, size_t datalen, RIL_Token t)
{
    int err;
    ATResponse *p_response = NULL;
    int response[2];
    int val_m = 0;
    char *line;

    err = at_send_command_singleline("AT+CLIR?", "+CLIR:", &p_response);

    if (err < 0 || p_response->success == 0) {
        goto error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);

    if (err < 0) {
        goto error;
    }

    /* <n> */
    err = at_tok_nextint(&line, &(response[0]));
    if (err < 0) {
        goto error;
    }

    /* <m> */
    err = at_tok_nextint(&line, &(response[1]));
    if (err < 0) {
        goto error;
    }

    LOGD("simcom_request_get_clir response<%d, %d>\n", response[0], response[1]);

    RIL_onRequestComplete(t, RIL_E_SUCCESS, response, sizeof(response));
    at_response_free(p_response);
    return;
error:
    at_response_free(p_response);
    LOGE("simcom_request_get_clir must never return error when radio is on\n");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

/*===========================================================================

FUNCTION simcom_request_set_clir

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_SET_CLIR, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_set_clir(void *data, size_t datalen, RIL_Token t)
{
    int val_n = ((int*)data)[0];
    int err;
    char *cmd = NULL;

    asprintf(&cmd, "AT+CLIR=%d", val_n);
    err = at_send_command(cmd, NULL);
    if (err < 0) {
        goto error;
    }
    
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    free(cmd);
    return;
    
error:
    LOGE("simcom_request_set_clir must never return error when radio is on\n");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    free(cmd);    
}

/*===========================================================================

FUNCTION simcom_request_dtmf_start

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_DTMF_START, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_dtmf_start(void *data, size_t datalen, RIL_Token t)
{
    char dtmf_ch = ((char *)data)[0];
    int err;
    char *cmd = NULL;

    asprintf(&cmd, "AT+VTS=%c", dtmf_ch);
    err = at_send_command(cmd, NULL);
    if (err < 0) {
        goto error;
    }
    
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    free(cmd);
    return;
    
error:
    LOGE("simcom_request_dtmf_start must never return error when radio is on\n");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    free(cmd);
}

/*===========================================================================

FUNCTION simcom_request_dtmf_stop

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_DTMF_STOP, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_dtmf_stop(void *data, size_t datalen, RIL_Token t)
{
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
}

/*===========================================================================

FUNCTION simcom_request_get_lastcall_disccause

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_LAST_CALL_FAIL_CAUSE, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_get_lastcall_disccause(void *data, size_t datalen, RIL_Token t)
{
    int err;
    ATResponse *p_response = NULL;
    int response = 0;
    int val_m = 0;
    char *line;
    char *callcause;
    
    err = at_send_command_singleline("AT+CEER", "+CEER:", &p_response);
    if (err < 0 || p_response->success == 0) {
        goto error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);
    if (err < 0) {
        goto error;
    }

    /* <report> */
    err = at_tok_nextstr(&line, &callcause);
    if (err < 0) {
        goto error;
    }

    LOGD("simcom_request_get_lastcall_disccause callcause<%s>\n", callcause);
    err = listmap_flag_from_string(callcause, g_call_cause, sizeof(g_call_cause) / sizeof(g_call_cause[0]), &response);
    if (err < 0) {
        goto error;
    }

    LOGD("simcom_request_get_lastcall_disccause response<%d>\n", response);

    RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, sizeof(response));
    at_response_free(p_response);
    return;
error:
    at_response_free(p_response);
    LOGE("simcom_request_get_lastcall_disccause must never return error when radio is on\n");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

/*===========================================================================

FUNCTION simcom_request_set_network_selection_manual

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_SET_NETWORK_SELECTION_MANUAL, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_set_network_selection_manual(void *data, size_t datalen, RIL_Token t)
{
    const char *mmcmnc = (const char *)data;
    int err;
    char *cmd = NULL;

    LOGD("simcom_request_set_network_selection_manual mmcmnc<%s>\n", mmcmnc);

    asprintf(&cmd, "AT+COPS=1,2,\"%s\"", mmcmnc);
    err = at_send_command(cmd, NULL);
    if (err < 0) {
        goto error;
    }
    
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    free(cmd);
    return;
    
error:
    LOGE("simcom_request_set_network_selection_manual must never return error when radio is on\n");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    free(cmd);
}

/*===========================================================================

FUNCTION simcom_request_operator_list

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_QUERY_AVAILABLE_NETWORKS, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_operator_list(void *data, size_t datalen, RIL_Token t)
{
    int err;
    int status;
    int skip;
    int listnum;
    int listavailnum;
    char **response;
    char *opstatus[4] = {"unknown", "available", "current", "forbidden"};
    char *line, *p;
    ATResponse *p_response = NULL;

    /* e.g: 
     AT+COPS=?
     +COPS: (2,"CHN-CUGSM","CU-GSM","46001",2),(1,"CHN-CUGSM","CU-GSM","46001",0),(3,"CHINA  MOBILE","CMCC","46000",0),,(0,1,2,3,4,5),(0,1,2)
     OK
     */
    err = at_send_command_singleline(
        "AT+COPS=?",
        "+COPS:", &p_response);
    if (err != 0) {
        goto error;
    }

    line = p_response->p_intermediates->line;
    err = at_tok_start(&line);
    if (err != 0) {
        goto error;
    }
    
    /* count number of operator */
    listnum = 0;
    for (p = line ; *p != '\0' ;p++) {
        if (*p == '(') listnum++;
    }

    listavailnum = 0;
    response = malloc(listnum * 4 * sizeof(char *));
    if (!response) {
        goto error;
    }       
    
    while(at_tok_matchstringbeginning(&line, "(") == 0)
    {
        do
        {
            err = at_tok_nextint(&line, &status);
            if (err < 0 || status < 0 || status >= 4) break;

            err = at_tok_nextstr(&line, &(response[4 * listavailnum + 0]));
            if (err < 0) break;

            err = at_tok_nextstr(&line, &(response[4 * listavailnum + 1]));
            if (err < 0) break;

            err = at_tok_nextstr(&line, &(response[4 * listavailnum + 2]));
            if (err < 0) break;

            response[4 * listavailnum + 3] = opstatus[status];

            err = at_tok_matchstring(&line, ")");
            if (err < 0) break;

            listavailnum++;
        }while(0);

        err = at_tok_matchstringbeginning(&line, ",");
        if (err < 0) break;
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, response, listavailnum * 4 * sizeof(char *));
    at_response_free(p_response);
    free(response);

    return;
error:
    LOGE("simcom_request_operator_list must not return error when radio is on\n");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
}

/*===========================================================================

FUNCTION simcom_request_get_perferred_network_type

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_GET_PREFERRED_NETWORK_TYPE, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_get_perferred_network_type(void *data, size_t datalen, RIL_Token t)
{
    int err;
    ATResponse *p_response = NULL;
    int response = 0;
    char *line;

    err = at_send_command_singleline("AT+CNMP?", "+CNMP:", &p_response);

    if (err < 0 || p_response->success == 0) {
        goto error;
    }

    line = p_response->p_intermediates->line;

    err = at_tok_start(&line);

    if (err < 0) {
        goto error;
    }

    err = at_tok_nextint(&line, &response);
    if (err < 0) {
        goto error;
    }

    if(response == 2) /* Automatic */
        response = 0;
    else if(response == 13) /* GSM Only*/
        response = 1;
    else if(response == 14) /* WCDMA Only*/
        response = 2;
    else if(response == 4)  /* CDMA Only */
        response = 5;
    else if(response == 8)  /* HDR Only */
        response = 6;
    else
        goto error;

    RIL_onRequestComplete(t, RIL_E_SUCCESS, &response, sizeof(int));
    at_response_free(p_response);
    return;
error:
    at_response_free(p_response);
    LOGE("simcom_request_get_network_type must never return error when radio is on\n");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
}

/*===========================================================================

FUNCTION simcom_request_set_perferred_network_type

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_SET_PREFERRED_NETWORK_TYPE, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.
S
RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_set_perferred_network_type(void *data, size_t datalen, RIL_Token t)
{
    int nttype = ((int*)data)[0];
    int err;
    char *cmd = NULL;

    if(nttype == 0 || nttype == 3 || nttype == 4 || nttype == 7)
        nttype = 2;  /* Automatic */
    else if(nttype == 1)
        nttype = 13; /* GSM Only*/
    else if(nttype == 2)
        nttype = 14; /* WCDMA Only*/
    else if(nttype == 5)
        nttype = 4; /* CDMA Only */
    else if(nttype == 6)
        nttype = 8; /* HDR Only */
    else
        goto error;

    asprintf(&cmd, "AT+CNMP=%d", nttype);
    err = at_send_command(cmd, NULL);
    if (err < 0) {
        goto error;
    }
    
    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    free(cmd);
    return;
    
error:
    LOGE("simcom_request_set_network_type must never return error when radio is on\n");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    free(cmd);
}

/*===========================================================================

FUNCTION simcom_request_get_callforward_status

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_QUERY_CALL_FORWARD_STATUS, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.
S
RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_get_callforward_status(void *data, size_t datalen, RIL_Token t)
{
    ATResponse *p_response;
    ATLine *p_cur;
    RIL_CallForwardInfo **pp_fwds;
    RIL_CallForwardInfo *p_fwds;
    RIL_CallForwardInfo *p_fwd;
    RIL_CallForwardInfo *p_args;
    char *subaddr;
    int subaddr_type;
    int err;
    int counts;
    int i;
    char *cmd = NULL;
    char *line;
    
    /* query the forward info */
    p_args = (RIL_CallForwardInfo *)data;

    if(p_args->serviceClass == 0 || p_args->serviceClass == 7) {
        asprintf(&cmd, "AT+CCFC=%d,2", p_args->reason);
    }
    else {
        asprintf(&cmd, "AT+CCFC=%d,2,,,%d", p_args->reason, p_args->serviceClass);
    }

    err = at_send_command_singleline(cmd, "+CCFC:", &p_response);
    if (err < 0 || p_response->success == 0) {
        goto error;
    }

    /* count the items */
    for (counts = 0, p_cur = p_response->p_intermediates
            ; p_cur != NULL
            ; p_cur = p_cur->p_next
    ) {
        counts++;
    }

    /* yes, there's an array of pointers and then an array of structures */
    pp_fwds = (RIL_CallForwardInfo **)alloca(counts * sizeof(RIL_CallForwardInfo *));
    p_fwds = (RIL_CallForwardInfo *)alloca(counts * sizeof(RIL_CallForwardInfo));
    memset (p_fwds, 0, counts * sizeof(RIL_Call));

    /* init the pointer array */
    for(i = 0; i < counts ; i++) {
        pp_fwds[i] = &(p_fwds[i]);
    }

    for (counts = 0, p_cur = p_response->p_intermediates
            ; p_cur != NULL
            ; p_cur = p_cur->p_next
    ) {
        p_fwd = pp_fwds[counts];
        line = p_cur->line;

        do
        {
            err = at_tok_start(&line);
            if (err < 0) goto error;
            
            /* Parse "<status>" */
            err = at_tok_nextint(&line, &(p_fwd->status));
            if (err < 0) goto error;
            
            /* Parse ",<class>" */
            err = at_tok_nextint(&line, &(p_fwd->serviceClass));
            if (err < 0) goto error;
            
            err = at_tok_hasmore(&line);
            if (!err) break;
            
            /* Parse "<address>,<type>" */      
            err = at_tok_nextstr(&line, &(p_fwd->number));
            if (err < 0) goto error;
            
            err = at_tok_nextint(&line, &(p_fwd->toa));
            if (err < 0) goto error;
            
            err = at_tok_hasmore(&line);
            if (!err) break;
            
            /* Parse "<subaddr>,<subaddr_type>" */      
            err = at_tok_nextstr(&line, &subaddr);
            if (err < 0) goto error;
            
            err = at_tok_nextint(&line, &subaddr_type);
            if (err < 0) goto error;
            
            err = at_tok_hasmore(&line);
            if (!err) break;
            
            /* Parse "<time>" */
            err = at_tok_nextint(&line, &(p_fwd->timeSeconds));
            if (err < 0) goto error;
        }while(0);

        /*
        LOGD("requestGetCallForwardStatus counts<%d>, status<%d>, reason<%d>, serviceClass<%d>, toa<%d>, number<%s>, timeSeconds<%d>", counts, 
            p_fwd->status, p_fwd->reason, 
            p_fwd->serviceClass, p_fwd->toa, 
            p_fwd->number, p_fwd->timeSeconds);
        */
        
        counts++;
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, pp_fwds,
            counts * sizeof (RIL_CallForwardInfo *));

    at_response_free(p_response);
    free(cmd);

    return;
error:
    LOGE("simcom_request_get_callforward_status must never return error when radio is on\n");
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
    free(cmd);
}

/*===========================================================================

FUNCTION simcom_request_set_callforward_status

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_SET_CALL_FORWARD, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.
S
RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_set_callforward_status(void *data, size_t datalen, RIL_Token t)
{
    RIL_CallForwardInfo *p_args;
    ATResponse   *p_response = NULL;    
    int err;
    char *cmd = NULL;
    
    /* set the forward info */
    p_args = (RIL_CallForwardInfo *)data;

    if(p_args->serviceClass == 0 || p_args->serviceClass == 7) {
        asprintf(&cmd, "AT+CCFC=%d,%d", p_args->reason, p_args->status);
    }
    else {
        asprintf(&cmd, "AT+CCFC=%d,%d,,,%d", p_args->reason, p_args->status, p_args->serviceClass);
    }

    err = at_send_command(cmd, &p_response);
    if (err < 0 || p_response->success == 0) {
        goto error;
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    at_response_free(p_response);
    free(cmd);

    return;
error:
    LOGE("simcom_request_set_callforward_status must never return error when radio is on\n");    
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
    free(cmd);
}

/*===========================================================================

FUNCTION simcom_request_get_callwaiting_status

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_QUERY_CALL_WAITING, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.
S
RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_get_callwaiting_status(void *data, size_t datalen, RIL_Token t)
{
    ATResponse *p_response;
    ATLine *p_cur;
    int err;
    int svclass;
    int counts;
    int i;    
    int *responses;
    int *response;
    char *line;    
    char *cmd = NULL;

    /* query the waiting info */
    svclass = ((const int *)data)[0];

    if(svclass == 0 || svclass == 7) {
        asprintf(&cmd, "AT+CCWA=1,2");
    }
    else {
        asprintf(&cmd, "AT+CCWA=1,2,%d", svclass);
    }

    err = at_send_command_singleline(cmd, "+CCWA:", &p_response);
    if (err < 0 || p_response->success == 0) {
        goto error;
    }

    /* count the items */
    for (counts = 0, p_cur = p_response->p_intermediates
            ; p_cur != NULL
            ; p_cur = p_cur->p_next
    ) {
        counts++;
    }

    /* yes, there's an array of pointers and then an array of structures */
    responses = (int *)alloca(counts * sizeof(int));
    memset (responses, 0, counts * sizeof(int));

    response = responses;
    for (counts = 0, p_cur = p_response->p_intermediates
            ; p_cur != NULL
            ; p_cur = p_cur->p_next
    ) {
        line = p_cur->line;

        err = at_tok_start(&line);
        if (err < 0) goto error;

        /* Parse "<status>" */
        err = at_tok_nextint(&line, &(response[0]));
        if (err < 0) goto error;
        
        /* Parse ",<class>" */
        err = at_tok_nextint(&line, &(response[1]));
        if (err < 0) goto error;

        /*
        LOGE("simcom_request_get_callwaiting_status counts<%d>, response0<%d>, response1<%d>", counts,
            response[0], response[1]);
        */
        
        counts++;
        response += 2;
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, responses,
            counts * sizeof (int));
    
    at_response_free(p_response);
    free(cmd);

    return;
error:
    LOGE("simcom_request_get_callwaiting_status must never return error when radio is on\n");        
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
    free(cmd);
}

/*===========================================================================

FUNCTION simcom_request_set_callwaiting_status

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_SET_CALL_WAITING, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.
S
RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_set_callwaiting_status(void *data, size_t datalen, RIL_Token t)
{
    ATResponse   *p_response = NULL;    
    int err;
    int mode;
    int srvclass;
    char *cmd = NULL;
    
    /* set the forward info */
    mode = ((const int *)data)[0];
    srvclass = ((const int *)data)[1];

    if(srvclass == 0 || srvclass == 7) {
        asprintf(&cmd, "AT+CCWA=1,%d", mode);
    }
    else {
        asprintf(&cmd, "AT+CCWA=1,%d,%d", mode, srvclass);
    }

    err = at_send_command(cmd, &p_response);
    if (err < 0 || p_response->success == 0) {
        goto error;
    }

    RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
    at_response_free(p_response);
    free(cmd);

    return;
error:
    LOGE("simcom_request_set_callwaiting_status must never return error when radio is on\n"); 
    RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
    at_response_free(p_response);
    free(cmd);
}

/*===========================================================================

FUNCTION simcom_request_stk_get_profile

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_STK_GET_PROFILE, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.
S
RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_stk_get_profile(void *data, size_t datalen, RIL_Token t)
{

}

/*===========================================================================

FUNCTION simcom_request_stk_set_profile

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_STK_SET_PROFILE, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.
S
RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_stk_set_profile(void *data, size_t datalen, RIL_Token t)
{

}

/*===========================================================================

FUNCTION simcom_request_stk_send_envelope_command

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_STK_SEND_ENVELOPE_COMMAND, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.
S
RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_stk_send_envelope_command(void *data, size_t datalen, RIL_Token t)
{

}

/*===========================================================================

FUNCTION simcom_request_stk_send_terminal_response

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_STK_SEND_TERMINAL_RESPONSE, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.
S
RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_stk_send_terminal_response(void *data, size_t datalen, RIL_Token t)
{

}

/*===========================================================================

FUNCTION simcom_request_stk_handle_call_setup_requested_from_sim

DESCRIPTION
    [REPLACE-ADD] please refer the command RIL_REQUEST_STK_HANDLE_CALL_SETUP_REQUESTED_FROM_SIM, 
  
PARAMETERS
	[in] data - 

DEPENDENCIES
  None.
S
RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void  simcom_request_stk_handle_call_setup_requested_from_sim(void *data, size_t datalen, RIL_Token t)
{

}

/*add by simcom*/
/*===========================================================================

FUNCTION simcom_request_set_mute

DESCRIPTION
  [REPLACE-ADD] please refer the command RIL_SIMCOM_SWITCH_GPS 
  
PARAMETERS
	[in] data - 
		

DEPENDENCIES
  None.

RETURN VALUE
  None.
  
SIDE EFFECTS
  None.

===========================================================================*/
void simcom_request_switch_gps(void *data, size_t datalen, RIL_Token t)
{
 	 ATResponse *p_response = NULL;
	int err;
        char *cmd = NULL;
	asprintf(&cmd, "AT+CGPS=%d", ((int *)data)[0]);

	//LOGD("OnRequest, before RIL_REQUEST_SET_MUTE :%s", cmd);

	err = at_send_command(cmd,  &p_response);
	free(cmd);
	
     if (err < 0 || p_response->success == 0) {
          RIL_onRequestComplete(t, RIL_E_GENERIC_FAILURE, NULL, 0);
      } else {
          RIL_onRequestComplete(t, RIL_E_SUCCESS, NULL, 0);
      }
      at_response_free(p_response);
}
/*end by simcom*/
#endif /*SIMCOM_RADIO*/

